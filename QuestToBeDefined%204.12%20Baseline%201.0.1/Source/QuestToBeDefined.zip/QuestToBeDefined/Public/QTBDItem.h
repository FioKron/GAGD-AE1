// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QuestToBeDefined.h"
#include "GameFramework/Actor.h"
#include "QTBDEntity.h"
#include "QTBDItem.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AQTBDItem : public AActor
{
	GENERATED_BODY()

public:

	/** This flag will state whether the player is overlaping the ProximitySphere, the player can then pick up this item */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bIsPlayerOverlapingPickupSphere;

	/** The name of this particular item */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = ItemFields)
	FString ItemName;

	/** The mass of this particular item, in kilograms */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = ItemFields)
	float ItemMass;

	/** The cost to purchase this item, if being sold instead, it can be sold for 75% of this value */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = ItemFields)
	float ItemValue;

	/** This flag relates to whether this item has been picked up or not */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bHasBeenPickedUp;

	/** An alternate system for scaling, rotating and translating an item */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = AlternateTransform)
	FQuat AltnerateTransformSystem;

	/**
		Update and obtain QTBDEntQuaternion

		@Return: FQuat QTBDEntQuaternion: Not only the return value;
		but this member will also recieve an update via this function
		before the function returns this value
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Get Alternate Transform System"), Category = MemberAquisition)
	FQuat GetQTBDEntQuaternion();
	
	/** Event for blueprint to use, to carry out actions, when the item has been picked up */
	UFUNCTION(BlueprintNativeEvent, meta = (DisplayName= "On Item Pick up"), Category = Pickup)
	void OnItemPickup();

	/** To be called for Blueprint to handle what occurs when Sacramento's grenade explodes */
	UFUNCTION(BlueprintNativeEvent, meta = (DisplayName= "Time for this grenade to explode"), Category = WeaponHandling)
	void TimeForExplosion();
	
	/** Use this whenever this item is in the player's inventory */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Has now been picked up"), Category = PickupValidation)
	void NowInPlayerInventory();
	
	/** Set the 'IsPlayerOverlapingPickupSphere' var. to true */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Player is overlaping the pickup sphere"), Category = PickupValidation)
	void PlayerOverlapingPickupSphere();

	/** Set the 'IsPlayerOverlapingPickupSphere' var. to false */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Player is not overlaping the pickup sphere"), Category = PickupValidation)
	void PlayerNotOverlapingPickupSphere();
	
protected:

	// The default constructor 
	AQTBDItem();

};
