// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDArmour.h"
#include "PoorBodyArmour.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API APoorBodyArmour : public AQTBDArmour
{
	GENERATED_BODY()
	

protected:

	/** The default constructor*/
	APoorBodyArmour();	
};
