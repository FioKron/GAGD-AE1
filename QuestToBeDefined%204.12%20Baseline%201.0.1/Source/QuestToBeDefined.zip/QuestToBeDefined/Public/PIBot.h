// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QuestToBeDefined.h"
#include "GameFramework/Character.h"
#include "BehaviorTree/BehaviorTree.h"
#include "QTBDCharacter.h"
#include "SoundDefinitions.h"
#include "PIBot.generated.h"

/**
 * 
 */

 /** This enum is for the current status of PIBot, his state that is */
UENUM(BlueprintType) // "BlueprintType" is essential to include, according to Rama
enum class EPIBotStatus : uint8
{
	PS_IdleDead					UMETA(DisplayName = "InIdleState"),
	PS_GiveIntro				UMETA(DisplayName = "GiveIntroductionToPlayer"),
	PS_InitFollowPlayer			UMETA(DisplayName = "InitialFollowingPlayer"),
	PS_Hide						UMETA(DisplayName = "HideFromSacramento"),
	PS_HarmlessFollowingPlayer  UMETA(DisplayName = "SacramentoIsNoThreat"),
	PS_RemainUnSighted			UMETA(DisplayName = "RemainOutOfSight"),
	PS_Dead						UMETA(DisplayName = "AtMinimumHealth")
};

UCLASS()
class QUESTTOBEDEFINED_API APIBot : public AQTBDCharacter
{
	GENERATED_BODY()

public:
	
	/** This capsule component is used for detecting when something is near PIBot, such as the player */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = ProximityDetection)
	USphereComponent* ProximityDetectionSphere;

	/** If it is the first encounter with the Player */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = ProximityFlags)
	bool bFirstEncounterWithPlayer;

	/** The current status (state) of PIBot */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = State)
	EPIBotStatus CurrentStatus;

	/** If the Player is near PIBot */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = ProximityFlags)
	bool bPlayerIsNearPIBot;

	/** The behaviour tree of PIBot, how PIBot will behave in game */
	UPROPERTY(EditAnywhere, Category = Behaviour)
	class UBehaviorTree* PIBotBehaviour;

	/** This member is used for stopping PIBot telling the Player about what they have in mind next,
	if the player goes far enough down the path while PIBot is saying this piece of dialog */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Sound)
	class UAudioComponent* DialogLinesAfterIntro;

	/** If PIBot has finished their introduction dialog */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bIntroFinished;

	/** For whether it is time to begin PIBot's introduction dialog */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bTimeToBeginIntro;

	/** Check if PIBot's intro should be interupted */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bIntroInterupted;

	/** If it is time to tell the player an important message*/
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bIsTimeToSayImportantMsg;

	/** Check to see if ComAd's intro has been interupted */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bComAdIntroHasBeenInterupted;

	/** To be set to true if PIBot has caught sight of Sacramento for the first time */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bHasPIBotSeenSacramentoFirstTime;

	/** For whether PIBot should stop hiding */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bPIBotShouldStopHiding;

	/** For whether PIBot should stay out of sight of the enemies up ahead */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bPIBotShouldRemainOutSight;

	/** For whether Sacramento is a threat to PIBot (as well as the player) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bSacramentoNotThreat;

	/** For debugging Sacramento's introduction, for the moment at least */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Begin Sacramento's introduction debug"), Category = Debugging)
	void InitiatePIBotForDebuggingSacramentosIntro();

	/** Inform PIBot that it is now time to remain out of sight of whats up ahead */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Time for PIBot to remain out of sight of whats up ahead"), Category = StateFlagModified)
	void TimeForPIBotToRemainOutSight();

	/** Inform PIBot, that is is now time to begin their introduction */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Time for PIBot to begin their introduction"), Category = StateFlagModified)
	void NowTimeForPIBotsIntroduction();

	/** Call this function to set 'HasPIBotSeenSacramentoFirstTime' to true */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "PIBot has now seen Sacramento for the first time"), Category = StateFlagModified)
	void PIBotNowSeenSacramentoFirstTime();

	/** If Sacramento turns out not to be a threat, call this function to set 'SacramentoNotThreat' to true */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Sacramento is not a threat"), Category = StateFlagModified)
	void SacramentoNoThreat();

	/** Inform PIBot that it is time to stop hiding */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Tell PIBot to stop hiding"), Category = StateFlagModified)
	void StopPIBotHiding();

	/** Set the 'IsTimeToSayImportantMsg' flag to true, to notify PIBot that it is time */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Notify is time to say important message"), Category = StateFlagModified)
	void NotifyTimeToSayImportantMsg();
	
	/** Call to initiate (to finish at the moment) PIBot's introduction sequence, when implemented, simply modifies flags for now */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Begin PIBot intro sequence"), Category = StateFlagModified)
	void BeginPIBotIntroSequence();

	/** Call to determine whether the player has chosen a name or not */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Has Player chosen Name?"), Category = Response)
	bool HasPlayerChosenName(FString PlayerName);

	/** Called whenever PIBot's intro has been interupted */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "PIBot's intro has been interupted", Category = StateFlagModified))
	void IntroNowInterupted();

	/** Called should ComAd's intro be interupted by the player */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "ComAd's intro has been interupted"), Category = StateFlagModified)
	void ComAdIntroInterupted();

protected:

	/** PIBot's default constructor */
	APIBot();

	/** Tick is used for continual checks, several times per second */
	virtual void Tick(float DeltaSeconds);
};
