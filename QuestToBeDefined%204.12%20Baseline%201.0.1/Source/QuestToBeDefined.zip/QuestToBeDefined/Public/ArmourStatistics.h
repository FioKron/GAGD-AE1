// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Components/ActorComponent.h"
#include "ArmourStatistics.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class QUESTTOBEDEFINED_API UArmourStatistics : public UActorComponent
{
	GENERATED_BODY()

public:	


	/** The damage resistance, taken from the asscociated armour */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Statistics)
	float DmgResistance;

	/** The armour's durability, also taken from the asscociated armour */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Statistics)
	float ArmDurability;

	/** The movement speed modifier of a particular piece of armour, taken from that armour's statistics */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Statistics)
	float MovSpdMod;

	/** The name of this piece of armour */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Statistics)
	FString ArmName;

	/** Modify/set up this Armour Statics component */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Armour Statistics"), Category = Modification)
	void ModifyArmStats(FString NewArmourName, float NewDmgResist, float NewArmrDura, float NewMoveSpdMod);

	/** Reduce this armour's durability by x */
	void ReduceArmourDurability(float IncomingDamage);

protected:

	// Does nothing for now
	UArmourStatistics();

};
