// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QuestToBeDefined.h"
#include "GameFramework/Character.h"
#include "QTBDWeapon.h"
#include "QTBDEntity.h"
#include "QTBDCharacter.generated.h"

/**
 * The super class for all characters in Quest: To Be Defined
 */
UCLASS()
class QUESTTOBEDEFINED_API AQTBDCharacter : public ACharacter
{
	GENERATED_BODY()

public:

	/** This character's name */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PlayerDefinedProperties)
	FString C_Name;

	/** A flag for whether this character can wear armour or not */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bCanWearArmour;

	/** The flag for whether this character is alive or not */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bIsAlive;

	/** 
		Deal damage to this character, this function can be overridden
		
		@Param: float DamageValue: The damage that should be done to this character 
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Damage this character"), Category = "Health")
	virtual void DamageCharacter(float DamageValue);

	/** Get this character's minimum health */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Minimum Health"), Category = "Health")
	float GetMinHealth();

	/** Get this character's maximum health */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Maximum Health"), Category = "Health")
	float GetMaxHealth();

	/** Get this character's current health */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Current Health"), Category = "Health")
	float GetHealth();

	/** Get this character's current energy */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Current Energy"), Category = "Energy")
	float GetEnergy();

	/** Get this character's minimum energy level */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Minimum Energy"), Category = "Energy")
	float GetMinEnergy();

	/** Get this character's maximum energy level */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Maximum Energy"), Category = "Energy")
	float GetMaxEnergy();

	/** Keep this character perpendicular to the ground */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Keep Perpendicular To Ground"), Category = "Rotation")
	void KeepPerpendicularToGround();
	
	/** Trim the text at both ends, then return the result */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Trim the whitespace from both ends of the text"), Category = NameValidation)
	FText CompleteTextTrim(FText ToBeTrimmed);

	/** Get what direction is forward, from this particular character's point of view
	@Return FRotator: Return the FRotator equating to the player's forward facing direction */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get character forward facing direction"), Category = CharacterFacing)
	FRotator FindCharForwardDirection();

protected:

	/** The default constructor */
	AQTBDCharacter();

	/** Modify the health of this character, either positivly or negativly, this function can also be overridden 
	@float HealthChangeValue: The value to add to the player's health, either a positive value to increase health, or a negative value to decrease health */
	virtual void ModifyHealth(float HealthChangeValue);

	/** The current health of this character */
	float C_Health;

	/** This character's maximum health */
	float C_MaxHealth;

	/** This character's minimum health */
	float C_MinHealth;

	/** This character's current energy, used for various movement actions */
	float C_Energy;

	/** This character's minimum energy level */
	float C_MinEnergy;

	/** This character's maximum energy level */
	float C_MaxEnergy;
};
