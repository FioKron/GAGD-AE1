// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.
#pragma once

#include "QuestToBeDefined.h"
#include "GameFramework/Character.h"
#include "QTBDCharacter.h"
#include "QTBDItem.h"
#include "QTBDWeapon.h"
#include "QTBDArmour.h"

#include "Unarmed.h"
#include "Runtime/Engine/Classes/Components/ActorComponent.h"
#include "Runtime/Engine/Classes/Components/ChildActorComponent.h"
#include "QuestToBeDefinedCharacter.generated.h"


UCLASS(config=Game)
class AQuestToBeDefinedCharacter : public AQTBDCharacter
{
	GENERATED_BODY()

public:

	/** To reference the UMG Asset in the Editor */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Widgets")
	TSubclassOf<UUserWidget> MainMenuBPReference;

	/** Camera boom positioning the camera behind the character */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
	USpringArmComponent* CameraBoom;

	/** Follow camera */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
	UCameraComponent* FollowCamera;

	/** A sphere on the left hand of the player character, that can detect if their hand collides with anything */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = UnarmedCombat)
	USphereComponent* LeftHandCollisionSphere;

	/** This flag is set to true if the player has a will to melee, by pressing T(for now) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = UnarmedCombat)
	bool bWantsToMelee;

	/** This sphere will check for any overlapping with pickups of all types */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PickupValidation)
	USphereComponent* PickupValidationSphere;
	
	/** Base turn rate for looking side to side, in deg/sec. Other scaling may affect the final rate. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
	float BaseTurnRate;

	/** Base look up/down rate, in deg/sec. Other scaling may affect final rate. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category= Camera)
	float BaseLookUpRate;

	/** This flag makes sure that the player can only interupted PIBot's intro, with the first begin overlap, of the trigger volume */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = OnlyAllowOneOverlapFlag)
	bool bPlayerInteruptedPIBotIntro;

	/** The trigger for PIBot to start their important message dialog will only trigger is this flag is not true */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = OnlyAllowOneOverlapFlag)
	bool bPlayerHasTriggeredPIBotToSayImportantMessage;

	/** The flag that makes sure the InteruptComAdIntro function, is only called once */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = OnlyAllowOneOverlapFlag)
	bool bPlayerInteruptedComAdIntro;

	/** The static mesh for the player's currently active weapon that is in their left hand */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Weapons)
	UStaticMeshComponent* P_LeftHandActWepMesh;

	/** A skeletal mesh for the player's currently active weapon that is in their right hand */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Weapons)
	USkeletalMeshComponent* P_RightHandActWepSkelMesh;

	/** The statistics of the player's weapon that is currently active in their left hand */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Weapons)
	UWeaponStatistics* P_LeftHandActiveWeaponStats;

	/** The statistics of the player's weapon that is currently active in their right hand */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Weapons)
	UWeaponStatistics* P_RightHandActiveWeaponStats;

	/** The statistics of the player's current active armour piece */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Armour)
	UArmourStatistics* P_ActiveArmourStats;

	/** The player's backpack, as an array of QTBDItems */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Inventory)
	TArray<AQTBDItem*> PlayerBackpack;

	/** The current mass of items/objects the player is carrying (in KG) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Inventory)
	float CurrentCarryingMass;

	/** The maximum mass of items/objects the player can carry (in KG), they cannot carry any more items over this limit */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Inventory)
	float MaximumCarryingMass;

	/** These two functions are for setting WantsToMelee to true and false, respectivly */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "The Player wants to deal melee damage"), Category = UnarmedCombat)
	void HasWillToMelee();

	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Disallow melee damage dealing"), Category = UnarmedCombat)
	void NoWillToMelee();

	/** Check if any particular item is in the player's backpack
	@AQTBDItem* ItemToFind: Find if this item is in the player's backpack
	@Return bool PlayerBackpack.Contains(ItemToFind): A simple check to see if the player's backpack (an array), contains ItemToFind
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Is item in Backpack"), Category = Inventory)
	bool IsItemInBackpack(AQTBDItem* ItemToFind);

	/** Modify the player character's active weapon
	@UWeaponStatistics* NewActiveWeapon: The weapon statistics associated with the player's new active weapon
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Active Weapon"), Category = ActiveWeapon)
	void ModActWep(UWeaponStatistics* NewActiveWeapon);

	/** Modify the player's current active piece of armour 
	@UArmourStatistics* NewActiveArmour: The armour statistics associated with the player's new active armour */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Active Armour"), Category = ActiveArmour)
	void ModActArm(UArmourStatistics* NewActiveArmour);
	
	/** Add an item to the backpack
	@AQTBDItem* ItemToAdd: The item to be added to the player's backpack
	@Return bool Success: For whether adding the item to the player's backpack was successful or not
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Add item to Backpack"), Category = Inventory)
	bool AddItemToBackpack(AQTBDItem* ItemToAdd);

	/** Remove a single instance of an item from the player's backpack, using the item's name 
	@AQTBDItem* ItemToRemove: The item to be removed from the player's backpack
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Remove item from Backpack"), Category = Inventory)
    void RemoveItemFromBackpack(AQTBDItem* ItemToRemove);

	/** Called once, to trigger PIBot to say their important message */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= TriggerPIBotsImportantMsgSequence), Category = InitSpawnActorSequence)
	void TriggerPIBotsImportantMsgSequence();

	/** Called once, when the player triggers the interuption of PIBot's intro */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= InteruptPIBotIntro), Category = InteruptOther)
	void InteruptPIBotIntro();

	/** Also called once, when the player triggers the interuption of ComAd's intro */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Interupt ComAd's intro sequence"), Category = InteruptOther)
	void InteruptComAdIntro();

	/** Called once, in response to PIBot asking what the player's name is, also returns what P_Name has been set to */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Set the player's name for the first time"), Category = PlayerDefinedProperties)
	void FirstTimeSetName(FString NewName);
	
	/** The New Game event, so that the character knows of it too */
	UFUNCTION(BlueprintNativeEvent, meta = (DisplayName= "New Game Button Pressed"))
	void NewGameBtnPressed();

	/** The player at minimum health event, do something when the player is at the minimum health*/
	UFUNCTION(BlueprintNativeEvent, meta = (DisplayName= "Player has minimum health"))
	void IsAtMinHealth();

	/** Put the player in cinematic mode or not */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Enable Player Cinematic Mode"), Category = "PlayerCinematic")
	void EnablePlayerCinematicMode();

	/** End cinematic mode for the player */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Disable Player Cinematic Mode"), Category = "PlayerCinematic")
	void DisablePlayerCinematicMode();
	
	/** Deal damage to the player, via the player's input */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Damage Self"), Category = "Damage")
	void DamageSelf();

	/** The 'DamageCharacter' function, from QTBDCharacter, overridden here, for the player */
	void DamageCharacter(float DamageValue)override;

	/** The player is currently in MainMenu */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Now In MainMenu"), Category = "CurrentLevel")
	void NowInMainMenu();

	/** The player is currently in QTBDIntro */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Now In QTBDIntro"), Category = "CurrentLevel")
	void NowInQTBDIntro();

	/** Get the player's current move speed multiplyer */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Current Player Movement Speed Multiplyer"), Category = "Movement")
	float GetCurrentMoveSpeedMultiplyer();

	/** Modify the player's current move speed multiplyer */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Current Player Movement Speed Multiplyer"), Category = "Movement")
	void ModifyCurrMoveSpdMulti(float NewMovementSpeedMulti);
	
	/** Add PlayerMainMenu to this Player's viewport */
	void ShowPlayerMainMenu();

protected:

	/** For the actual widget */
	UUserWidget* PlayerMainMenu;

	/** Changes this character's current health */
	void ModifyHealth(float HealthChangeValue)override;

	/** Changes this character's current energy*/
	void ModifyEnergy(float EnergyChangeValue);

	/** The new constructor for all classes that use FObjectInitilizer */
	AQuestToBeDefinedCharacter();

	/** Called for forwards/backward input */
	void MoveForward(float Value);

	/** Called for side to side input */
	void MoveRight(float Value);

	/** This is the modifier to the player's speed, when they are not sprinting */
	float PlayerMovementSpeedMultiplyer;

	/** 
	 * Called via input to turn at a given rate. 
	 * @param Rate	This is a normalized rate, i.e. 1.0 means 100% of desired turn rate
	 */
	void TurnAtRate(float Rate);

	/**
	 * Called via input to turn look up/down at a given rate. 
	 * @param Rate	This is a normalized rate, i.e. 1.0 means 100% of desired turn rate
	 */
	void LookUpAtRate(float Rate);

	/** Handler for when a touch input begins. */
	void TouchStarted(ETouchIndex::Type FingerIndex, FVector Location);

	/** Handler for when a touch input stops. */
	void TouchStopped(ETouchIndex::Type FingerIndex, FVector Location);

	/** Fields */

	/** The energy drain caused to the player by sprinting */
	float SprintEnergyDrain;

	/** Handle sprint behaviour in this function */
	void HandleSprinting();

	// The multiplyer for the player's movespeed while sprinting
	float SprintMoveSpeedMod;

	// The multiplyer for the player's movespeed while sprinting
	float SprintAccelRateMod;

	// The default values for the players max accelartion and max walk speed
	float DefaultMaxAccel;
	float DefaultMaxWalkSpeed;

	// A check flag, to tell if the player is sprinting
	bool bIsSprinting;

	// APawn interface
	virtual void SetupPlayerInputComponent(class UInputComponent* InputComponent) override;
	// End of APawn interface

	// For continious checks over time
	virtual void Tick(float DeltaSeconds)override;
};

