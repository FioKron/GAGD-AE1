// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "PIBot.h"
#include "QTBDCharacter.h"
#include "SoundSystem.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API ASoundSystem : public AActor
{
	GENERATED_BODY()

public:
	
	// Functions:
	
	/** 
		Description: Set up a reference to the single instance of PIBot

		@Param: APIBot* PIBotInst: The instance of PIBot to use for 
		this introduction sequence
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Handle PIBot's Introduction Sequence"), Category = DialogSequences)
	void HandlePIBotIntroSequence(APIBot* PIBotInst);

	/**
		Description: Set up a reference to the single instance of the Combat Admin

		@Param: AQTBDCharacter* ComAdInst: The instance of the Combat Admin to use for
		this introduction sequence
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Handle the Combat Admin's Introduction Sequence"), Category = DialogSequences)
	void HandleComAdIntroSequence(AQTBDCharacter* ComAdInst);

	/**
		Initiate this event, to handle PIBot's introduction getting interrupted
	*/
	UFUNCTION(BlueprintImplementableEvent, meta = (DisplayName = "Handle PIBot Intro. Sequence Interruption"), Category = DialogSequences)
	void HandlePIBotIntroSequenceIntteruption();

	/**
		Initiate this event, to handle the Combat Admin's introduction sequence getting intterupted
	*/
	UFUNCTION(BlueprintImplementableEvent, meta = (DisplayName = "Handle the Combat Admin's Intro. Sequence Interruption"), Category = DialogSequences)
	void HandleComAdIntroSequenceIntterupted();

	// Variables:

	/** 
		A reference to PIBot, involved in the first and second
		introduction that the Player will come across in the first level
	*/
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = SoundOutputActors)
	APIBot* PIBotReference;

	/** 
		As well as a reference to the Combat Admin (QTBDcharacter for now, as there is no combat admin class)
	*/
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = SoundOutputActors)
	AQTBDCharacter* ComAdReference;

protected:

	// Variables:

	/** For playing sound when required */
	//UAudioComponent* SoundEmitter;
	
	// Functions:
	
	/** The standard constructor for this 'static' function class */
	ASoundSystem();
};
