// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QuestToBeDefined.h"
#include "GameFramework/Actor.h"
#include "QuestToBeDefinedCharacter.h"
#include "QTBDWeapon.h"
#include "BrickWeapon.generated.h"

/**
 * This will be the first weapon the player can obtain, a brick projectile, that can be reused multiple times
 */
UCLASS()
class QUESTTOBEDEFINED_API ABrickWeapon : public AQTBDWeapon
{
	GENERATED_BODY()

public:

	/** For whether the brick is in flight or not */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bBrickIsInFlight;
	
	/** Call this function whenever the brick is in flight */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Brick Now In Flight"), Category = MotionFlagModifier)
	void BrickNowInFlight();

	/** Call this function should the brick no longer be in flight */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Brick Not In Flight"), Category = MotionFlagModifier)
	void BrickNotInFlight();

protected:

	/** The default constructor for this BrickWeapon */
	ABrickWeapon();
};
