// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDWeapon.h"
#include "QuestToBeDefined.h"
#include "SacramentoSlugShotgun.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API ASacramentoSlugShotgun : public AQTBDWeapon
{
	GENERATED_BODY()

public:

	/** A flag for whether the owner of this weapon (Sacramento), has been spawned in or not, Sacramento can be spawned in at multiple points now */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bSacramentoHasBeenSpawnedIn;

	/** This function will be called when Sacramento has been spawned into the level */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "State that Sacramento has now been spawed in"), Category = FlagModification)
	void StateSacramentoNowSpawnedIn();

protected:
	// The default constructor 
	ASacramentoSlugShotgun();
	
};
