// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "LightBodyArmour.h"


ALightBodyArmour::ALightBodyArmour()	
{
	// Set up the member variables for this piece of armour
	ItemName = "Light Body Armour";
	DamageResistance = 0.10f;
	ArmourDurability = 100.0f;
	MoveSpeedModification = 0.20f;

	ItemValue = 500.0f;
	ItemMass = 10.0f;

	// Also initilize the statistics for this piece of armour
	ArmourStats = CreateDefaultSubobject<UArmourStatistics>(TEXT("ArmourStats"));
	ArmourStats->ModifyArmStats(ItemName, DamageResistance, ArmourDurability, MoveSpeedModification);
}

