// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "QTBDLevelScriptActor.h"



/*
(Originally implemented by Rama)
Solus Level BP Template
�
 by Rama
 */


AQTBDLevelScriptActor::AQTBDLevelScriptActor() 
{
	QTBDLevelName = NAME_None;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//				QTBD Level Begin Play
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//Actor.h 		BeginPlay()
void AQTBDLevelScriptActor::BeginPlay()
{
	Super::BeginPlay();
	
	// For getting the Player Character:
	UWorld* GameWorld = this->GetWorld();

	// Notify the Player Character of where they are:
	AQuestToBeDefinedCharacter* PlayerCharacter = Cast<AQuestToBeDefinedCharacter>(UGameplayStatics::GetPlayerCharacter(GameWorld, 0));
	PlayerCharacter->NowInMainMenu();

	// Allow the Player to navigate the main menu
	AQuestPlayerController* PlayerController = Cast<AQuestPlayerController>(PlayerCharacter->GetController());
	PlayerController->SetCursorVisibility(true);

	AQuestToBeDefinedGameMode* ActiveGameMode = Cast<AQuestToBeDefinedGameMode>(UGameplayStatics::GetGameMode(GameWorld));
	
	// Show the main menu to the Player:
	PlayerCharacter->ShowPlayerMainMenu();

	//UE_LOG(YourLog,Error,TEXT("STREAMING LEVEL BEGIN PLAY�%s"), *GetName());
}


/**

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//		 			QTBD Level End Play
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~

void AQTBDLevelScriptActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	/*
	UE_LOG(YourLog,Error,TEXT("STREAMING LEVEL UNSTREAMED (name should not be none)�%s"), *GetName());
	UE_LOG(YourLog,Error,TEXT("Victory!!!"));
	UE_LOG(YourLog,Error,TEXT("RUN ALL UNSTREAMING LEVEL LOGIC HERE"));
	

	//Save Level Just Before Exiting
	QTBDLevel__UpdateLevelSaveData();


	Super::OnRemoveFromWorld();
	//~~~~~~~~~~
}

void AQTBDLevelScriptActor::QTBDLevel__UpdateLevelSaveData()
{
	//Save Level Data
}

*/
void AQTBDLevelScriptActor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	//~~~~~~~~~~~~~~

	//UE_LOG(YourLog,Warning,TEXT("Level Name Is:�%s"), *QTBDLevelName);
}
