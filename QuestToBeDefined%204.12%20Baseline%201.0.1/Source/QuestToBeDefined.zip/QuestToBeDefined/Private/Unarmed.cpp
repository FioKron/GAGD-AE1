// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "Unarmed.h"


AUnarmed::AUnarmed()
	
{
	// Name this item 'Unarmed'
	ItemName = "Unarmed";

	// This is the default melee weapon for the player, so it does not use ammo
	bUsesAmmo = false;

	// and is also not a firearm,
	bIsFirearm = false;

	// as well as not requiring the right hand weapon slot
	bRequiresRightArm = false;

	// Five damage, the lowest damage for any weapon, subject to change
	WeaponDamage = 5.0f;

	// Set up the weapon statistics member var. To get the stats of this weapon when required
	WeaponStats = CreateDefaultSubobject<UWeaponStatistics>(TEXT("WeaponStats"));
	WeaponStats->ModifyWeaponStats(WeaponDamage, bUsesAmmo, bRequiresRightArm, bIsFirearm, InitialAmmoCount, MaximumAmmoCount, AmmoPerStorageMech, CurrentAmmoInStorMech, DelayUntilNextAttack, WeaponReloadDuration, ItemName);
}


