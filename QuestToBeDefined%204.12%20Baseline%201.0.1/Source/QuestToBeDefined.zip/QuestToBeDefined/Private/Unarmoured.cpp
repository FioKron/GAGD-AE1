// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "Unarmoured.h"

AUnarmoured::AUnarmoured()
	
{
	// Setting up this 'armour's' member variables 
	ItemName = "Unarmoured";
	DamageResistance = 0.0f;
	ArmourDurability = 0.0f;
	MoveSpeedModification = 0.0f;
	ItemMass = 0.0f;
	ItemValue = 0.0f;

	ArmourStats = CreateDefaultSubobject<UArmourStatistics>(TEXT("ArmourStatistics"));
	ArmourStats->ModifyArmStats(ItemName, DamageResistance, ArmourDurability, MoveSpeedModification);
}


