// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "PIBot.h"


APIBot::APIBot()
	
{
	// Set size for the collision capsule 
	GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);

	// Rotate when the AI controller wants to rotate PIBot
	bUseControllerRotationPitch = true;
	bUseControllerRotationYaw = true;
	bUseControllerRotationRoll = true;
	
	// Setup the proximity sphere
	ProximityDetectionSphere = CreateDefaultSubobject<USphereComponent>(TEXT("ProximityDetectionSphere"));
	ProximityDetectionSphere->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepRelativeTransform);
	ProximityDetectionSphere->InitSphereRadius(400.0f); // Radius is wide enough, to cover the whole path, so PIBot will get up when the player gets close enough
	ProximityDetectionSphere->bVisible = false;
	ProximityDetectionSphere->SetVisibility(false);

	// Configure character movement
	GetCharacterMovement()->bOrientRotationToMovement = true; // Character moves in the direction of input...	
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 54.0f, 0.0f); // ...at this rotation rate 54 is a test
	GetCharacterMovement()->JumpZVelocity = 600.f;
	GetCharacterMovement()->AirControl = 0.2f;

	// It will be the first encounter with the player, upon starting, for now
	bFirstEncounterWithPlayer = true;

	// The player will not be near PIBot, even on the first level
	bPlayerIsNearPIBot = false;

	// PIBot will have be assumed to have not finished their introduction 
	bIntroFinished = false;

	// It is not time for PIBot to begin their introduction either
	bTimeToBeginIntro = false;

	// PIBot's intro will not have been interupted upon construction
	bIntroInterupted = false;

	// PIBot will not have been notified upon construction
	bIsTimeToSayImportantMsg = false;

	// ComAd's intro will not have been interupted either, as per PIBot's intro
	bComAdIntroHasBeenInterupted = false;

	// PIBot will not have seen Sacramento for the first time just yet
	bHasPIBotSeenSacramentoFirstTime = false;

	// When this variable is checked, to start off with, PIBot should not stop hiding
	bPIBotShouldStopHiding = false;

	// It is unknown to PIBot whether Sacramento is a threat though
	bSacramentoNotThreat = false;

	// PIBot should not remain out of sight just yet either, as that event is yet to happen
	bPIBotShouldRemainOutSight = false;

	// The initial status for PIBot, lying on the ground, seemingly dead
	CurrentStatus = EPIBotStatus::PS_IdleDead;

	// Setup the health and energy of PIBot as the player's defaults for now as well
	C_MaxHealth = 100;
	C_MaxEnergy = 100;
	
	C_Health = 100;
	C_Energy = 100;
	
	C_MinHealth = 0;
	C_MinEnergy = 0;

	// PIBot can wear armour, just in case...
	bCanWearArmour = true;
}

/** Make sure that PIBot is always perpendicular to the ground, for now */
void APIBot::Tick(float DeltaSeconds)
{
	KeepPerpendicularToGround();
}

/** Inform PIBot that it is now time to give their introduction to the player */
void APIBot::NowTimeForPIBotsIntroduction()
{
	bTimeToBeginIntro = true;
}


/** Do what is required for PIBot's introduction */
void APIBot::BeginPIBotIntroSequence()
{	
	// This function just sets this flag to true, for now
	
	// PIBot has now finished their intro sequence
	bIntroFinished = true;

	// It is also no longer PIBot's first encounter with the player
	bFirstEncounterWithPlayer = false;
}

/** Check whether the player has chosen a name or not */
bool APIBot::HasPlayerChosenName(FString PlayerName)
{
	// If the player's name is 'Unknown' (the default name) they have not chosen a custom name,
	// so return false, else, return true
	if (PlayerName == "Unknown")
	{
		return false;
	}
	else
	{
		return true;
	}
}

/** If PIBot has caught sight of Sacramento, make this state flag reflect such */
void APIBot::PIBotNowSeenSacramentoFirstTime()
{
	bHasPIBotSeenSacramentoFirstTime = true;
}

/** Tell PIBot to stop hiding */
void APIBot::StopPIBotHiding()
{
	bPIBotShouldStopHiding = true;
}

/** If Sacramento is not a threat, have them teleport back to the player and follow them again */
void APIBot::SacramentoNoThreat()
{
	// Sacramento is known to not be a threat
	bSacramentoNotThreat = true;
}

/** PIBot's intro has been interupted; set this state flag to true */
void APIBot::IntroNowInterupted()
{
	bIntroInterupted = true;
}

/** Similar to the above function, ComAd's intro has been interupted this time though */
void APIBot::ComAdIntroInterupted()
{
	bComAdIntroHasBeenInterupted = true;
}

/** Notify PIBot, that it is now time to say their important message */
void APIBot::NotifyTimeToSayImportantMsg()
{
	bIsTimeToSayImportantMsg = true;
}

/** Notify PIBot that it is now time to remain out of sight of whats up ahead */
void APIBot::TimeForPIBotToRemainOutSight()
{
	bPIBotShouldRemainOutSight = true;
}

/** Do what is required to set up PIBot for debugging Sacramento's introduction */
void APIBot::InitiatePIBotForDebuggingSacramentosIntro()
{
	bFirstEncounterWithPlayer = false;
	bIntroFinished = true;
	CurrentStatus = EPIBotStatus::PS_InitFollowPlayer;
}