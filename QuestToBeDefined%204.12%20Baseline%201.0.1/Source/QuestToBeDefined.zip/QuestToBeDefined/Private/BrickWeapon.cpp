// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "BrickWeapon.h"


ABrickWeapon::ABrickWeapon()
{
	// Set the name of this weapon
	ItemName = "BrickWeapon";

	// As well as this weapon's mass and value
	ItemMass = 4.0f;
	ItemValue = 75.0f;

	// At the moment, 50 damage for this weapon, for testing, subject to change
	WeaponDamage = 50.0f;

	// Set up this weapon's use of ammo
	bUsesAmmo = true;

	// This brick is not a gun however
	bIsFirearm = false;

	// As well as how ammo is handled for this weapon, as there is 1 brick here, 1 for all of these vars
	InitialAmmoCount = 1.0f;
	MaximumAmmoCount = 1.0f;
	AmmoPerStorageMech = 1.0f;
	CurrentAmmoInStorMech = 1.0f;

	// As this weapon has an ammo. Count of one, it does not require reloading and there is no delay between picking it up and throwing it
	WeaponReloadDuration = 0.0f;
	DelayUntilNextAttack = 0.0f;

	// For this brick, it will not start off in flight
	bBrickIsInFlight = false;

	// This brick does not require the use of the player's right arm
	bRequiresRightArm = false;

	// Set up the weapon statistics member var. To get the stats of this weapon when required
	WeaponStats = CreateDefaultSubobject<UWeaponStatistics>(TEXT("WeaponStats"));
	WeaponStats->ModifyWeaponStats(WeaponDamage, bUsesAmmo, bRequiresRightArm, bIsFirearm, InitialAmmoCount, MaximumAmmoCount, AmmoPerStorageMech, CurrentAmmoInStorMech, DelayUntilNextAttack, WeaponReloadDuration, ItemName);
}

/** Set this flag to true */
void ABrickWeapon::BrickNowInFlight()
{
	bBrickIsInFlight = true;
}

/** Set this flag to false */
void ABrickWeapon::BrickNotInFlight()
{
	bBrickIsInFlight = false;
}