// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "SoundSystem.h"

/** Initilise this function class: (Resolve issues with this later)*/
ASoundSystem::ASoundSystem()
{
	//SoundEmitter = CreateDefaultSubobject<UAudioComponent>(FName("SoundEmitter"));
	//SoundEmitter->bAutoActivate = false;
}

/** 
	The first two functions set the reference to the single instance of PIBot;
	for Blueprint to handle their introduction:
*/

void ASoundSystem::HandlePIBotIntroSequence(APIBot* PIBotInst)
{
	PIBotReference = PIBotInst;
}


void ASoundSystem::HandleComAdIntroSequence(AQTBDCharacter* ComAdInst)
{
	ComAdReference = ComAdInst;
}

/**
void ASoundSystem::HandlePIBotIntroSequenceIntteruption(APIBot* PIBotInst)
{
	
}


void ASoundSystem::HandleComAdIntroSequenceIntterupted(APIBot* PIBotInst)
{

}
*/

