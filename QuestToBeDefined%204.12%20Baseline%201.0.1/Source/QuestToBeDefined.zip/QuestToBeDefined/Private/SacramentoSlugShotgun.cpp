// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "SacramentoSlugShotgun.h"


ASacramentoSlugShotgun::ASacramentoSlugShotgun()
	
{
	// Set the name of this weapon
	ItemName = "Slug Shotgun";

	// At the moment, 16 damage for this weapon, subject to change (for balance, test later)
	WeaponDamage = 16.0f;

	// Setup this weapon's use of ammo
	bUsesAmmo = true;

	// It is also a gun
	bIsFirearm = true;

	// This shotgun does require the right hand weapon slot
	bRequiresRightArm = true;

	// As well as how ammo is handled for this weapon, 6 slugs can be loaded, Sacramento also has a large ammo supply
	InitialAmmoCount = 1000.0f;
	MaximumAmmoCount = 1000.0f;
	AmmoPerStorageMech = 6.0f;
	CurrentAmmoInStorMech = AmmoPerStorageMech;

	// Delay between attacks and time that it takes for this weapon to be reloaded are subject to balance, test values for now
	DelayUntilNextAttack = 1.30f; // This is the time that the shotgun_fire_hip animation will take, hence this delay
	WeaponReloadDuration = 4.30f; // Similarary, this is the time that it takes for the reload animation to be completed

	// Set up the weapon statistics member var. To get the stats of this weapon when required
	WeaponStats = CreateDefaultSubobject<UWeaponStatistics>(TEXT("WeaponStats"));
	WeaponStats->ModifyWeaponStats(WeaponDamage, bUsesAmmo, bRequiresRightArm, bIsFirearm, InitialAmmoCount, MaximumAmmoCount, AmmoPerStorageMech, CurrentAmmoInStorMech, DelayUntilNextAttack, WeaponReloadDuration, ItemName);

	// As this is Sacramento's shotgun, it can only be given to Sacramento if they have been spawned in, so false for now
	bSacramentoHasBeenSpawnedIn = false;
}

// Sacramento has now been spawned in, so set this flag to true
void ASacramentoSlugShotgun::StateSacramentoNowSpawnedIn()
{
	bSacramentoHasBeenSpawnedIn = true;
}

