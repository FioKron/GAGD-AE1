// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "AIController.h"
#include "PrivateMattersonController.generated.h"

/**
 * An AIController that Private Matterson uses
 */
UCLASS()
class QUESTTOBEDEFINED_API APrivateMattersonController : public AAIController
{
	GENERATED_BODY()
	
protected:

	APrivateMattersonController();
	
	
};
