// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDWeapon.h"
#include "MachinePistol.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AMachinePistol : public AQTBDWeapon
{
	GENERATED_BODY()

protected:

	/** The default constructor for this machine pistol */
	AMachinePistol();
	

};
