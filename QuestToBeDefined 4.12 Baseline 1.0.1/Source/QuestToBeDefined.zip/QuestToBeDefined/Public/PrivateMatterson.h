// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDCharacter.h"
#include "WeaponStatistics.h"
#include "ArmourStatistics.h"
#include "BrickWeapon.h"
#include "PvtMattersonAssaultRifleBullet.h"
#include "SacramentosShotgunSlugProj.h"
#include "PrivateMatterson.generated.h"

/**
* Private Matterson, unlike Sacramento, will be the first enemy the player encounters, they won't be
* friendly towards them at all, shooting at them on sight
*/

/** The enum for a type that is used as Matterson's current status */
UENUM(BlueprintType)
enum class EPvtMattersonStatus : uint8
{
	PMS_Idle			 UMETA(DisplayName = "InIdleState"),
	PMS_Attacking		 UMETA(DisplayName = "AttackingTarget"),
	PMS_Strafe			 UMETA(DisplayName = "StrafingForLOS"),
	PMS_Seek_Target		 UMETA(DisplayName = "LookingForTarget"),
	PMS_Target_Destroyed UMETA(DisplayName = "TargetDestroyed"),
	PMS_Dead			 UMETA(DisplayName = "AtMinimumHealth")
};

UCLASS()
class QUESTTOBEDEFINED_API APrivateMatterson : public AQTBDCharacter
{
	GENERATED_BODY()
public:

	

	/** The behaviour tree for Private Matterson, how they will behave in game */
	UPROPERTY(EditAnywhere, Category = Behaviour)
	class UBehaviorTree* PvtMatterBehaviour;

	/** The current status (state) of Private Matterson */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = State)
	EPvtMattersonStatus CurrentStatus;

	/** The statistics of Private Matterson's active weapon */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Weapons)
	UWeaponStatistics* Matt_ActiveWeaponStats;

	/** The statistics of Private Matterson's current armour piece */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Armour)
	UArmourStatistics* Matt_ActiveArmourPieceStats;

	/** This flag is for whether or not Private Matterson has their rifle ready to fire */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bHasRifleReady;

	/** A flag for whether another instance of Pvt. Matterson (whom is nearby to this particular instance) has line of sight to a target */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = StateFlags)
	bool bAnotherInstanceHasLOS;

	/** For whether this instance's line of sight blocked by another one*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = StateFlags)
	bool bLOSBlockedByAnotherInst;

	/** For whether it is time for Pvt. Matterson to equip their primary weapon */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bTimeToEquipPrimary;

	/** Notify all other instances of Pvt. Matterson, that are in close enough proximity, that this one has line of sight
	@AActor* CloseProxActors: An array of actors that are in close proximity, these actors, after filtering,
	will be cast to APrivateMatterson
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Notify other instances of Pvt. Matterson, that this one has line of sight"), Category = StateFlagModification)
	void NotifyOtherInstancesOfThisHavingLOS(TArray<AActor*> CloseProxActors);

	/** Modify HasRifleReady to show that what this function does, is now the case */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Pvt. Matterson has their rifle ready to fire"), Category = StateFlagModification)
	void ReadyToFireRifle();

	/** Modify TimeToEquipPrimary, to show that what this function does, is now the case*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Time for Pvt. Matterson to equip their rifle"), Category = StateFlagModification)
	void EquipPrimaryWeapon();

	/** These two functions modify Private Matterson's active weapon and armour, respectivly */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Pvt. Matterson's active weapon"), Category = Weapons)
	void ModMattActWeaponStats(UWeaponStatistics* NewActiveWeapon);

	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Pvt. Matterson's active armour piece"), Category = Armour)
	void ModMattActArmourStats(UArmourStatistics* NewActiveArmour);

	/** Check if Pvt. Matterson is at their minimum health */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Is Private Matterson at their minimum health?"), Category = Health)
	bool IsPvtMattAtMinHeal();

	/** An event for Blueprint to use, called should Private Matterson be at minimum health, in the ModifyHealth function */
	UFUNCTION(BlueprintNativeEvent, meta = (DisplayName= "Pvt. Matterson is at their minimum health"), Category = Health)
	void IsAtMinHealth();

	/** Override the DamageCharacter function from QTBDCharacter, to allow for Pvt. Matterson's armour to mitigate the damage done to them by any source */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Damage Pvt. Matterson"), Category = Health)
	void DamageCharacter(float DamageValue)override;

protected:

	// The default constructor for Private Matterson
	APrivateMatterson();

	/** A slight alteration to the ModifyHealth function of the super class */
	void ModifyHealth(float HealthChangeValue)override;
};
