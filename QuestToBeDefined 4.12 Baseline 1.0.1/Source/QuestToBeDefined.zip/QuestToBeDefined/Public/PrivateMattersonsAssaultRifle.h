// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDWeapon.h"
#include "PrivateMattersonsAssaultRifle.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API APrivateMattersonsAssaultRifle : public AQTBDWeapon
{
	GENERATED_BODY()
	
protected:
	/** The default constructor */
	APrivateMattersonsAssaultRifle();	
};
