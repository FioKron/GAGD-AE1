// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDArmour.h"
#include "LightBodyArmour.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API ALightBodyArmour : public AQTBDArmour
{
	GENERATED_BODY()
	
public:

protected:

	/** The default constructor*/
	ALightBodyArmour();
};
