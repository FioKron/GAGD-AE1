// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

/**
	Is to be used by any QTBD class or sub-class; for Quaternion testing
*/
#include "GameFramework/Actor.h"
#include "QTBDEntity.generated.h"

UCLASS()
class QUESTTOBEDEFINED_API UQTBDEntity : public UObject
{
	GENERATED_BODY()
	
public:	
	
	// Variables:

	/**
		An alternate actor quaternion for testing and understanding purposes:
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = AltLSRSystem )
	FQuat QTBDEntQuaternion;

	// Functions:

	/**
		The standard constructor
	*/
	UQTBDEntity();
};
