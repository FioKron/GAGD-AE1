// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "AIController.h"
#include "QuestToBeDefined.h"
#include "SacramentoController.generated.h"

/**
 * An AIController that Sacramento uses
 */
UCLASS()
class QUESTTOBEDEFINED_API ASacramentoController : public AAIController
{
	GENERATED_BODY()
	
	
protected:

	ASacramentoController();
	
};
