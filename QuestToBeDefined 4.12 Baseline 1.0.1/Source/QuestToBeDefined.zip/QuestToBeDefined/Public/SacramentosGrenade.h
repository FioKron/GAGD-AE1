// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDWeapon.h"
#include "SacramentosGrenade.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API ASacramentosGrenade : public AQTBDWeapon
{
	GENERATED_BODY()
	
	/** The default constructor for SacramentosGrenade */
	ASacramentosGrenade();


public:
	
	/** The time (in seconds), that upon deployment (being thrown), before this grenade explodes */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Damage)
	float TimeTillExplosion;

	/** A weapon handling flag, for whether this grenade is primed to explode */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = WeaponHandling)
	bool bGrenadeIsPrimed;

	/** Set bIsGrenadePrimed to true upon calling this function */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Prime this grenade"), Category = WeaponHandling)
	void PrimeGrenade();

	/** Overidden Tick function, used to handle decrementing TimeTillExplosion */
	void Tick(float DeltaSeconds)override;
	
};
