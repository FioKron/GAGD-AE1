// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDItem.h"
#include "ArmourStatistics.h"
#include "QTBDArmour.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AQTBDArmour : public AQTBDItem
{
	GENERATED_BODY()
	

	
public:

	/** The resistance to all damage (for now), that this armour confers, between 0 and 1, as this is taken away from the damage done to the wearer of it */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Specification)
	float DamageResistance;

	/** The durability of this particular piece of armour, as a percentage, starting off by default at 100% */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Specification)
	float ArmourDurability;

	/** The movement speed modifier of this armour piece, to be taken away from their base movement speed */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Specification)
	float MoveSpeedModification;

	/** The statistics for this piece of armour */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Statistics)
	UArmourStatistics* ArmourStats;	

protected:
	
	/** The default constructor */
	AQTBDArmour();
};
