// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDWeaponProjectile.h"
#include "PvtMattersonAssaultRifleBullet.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API APvtMattersonAssaultRifleBullet : public AQTBDWeaponProjectile
{
	GENERATED_BODY()
	
public:

	/** The default constructor for bullets fired from this assault rifle */
	APvtMattersonAssaultRifleBullet();
	
	
};
