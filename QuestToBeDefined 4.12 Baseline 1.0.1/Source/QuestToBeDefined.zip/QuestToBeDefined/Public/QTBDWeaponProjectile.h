// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDItem.h"
#include "QTBDWeaponProjectile.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AQTBDWeaponProjectile : public AQTBDItem
{
	GENERATED_BODY()
	
public:

	/** The default constructor for QTBDWeaponProjectiles */
	AQTBDWeaponProjectile();
	
	
};
