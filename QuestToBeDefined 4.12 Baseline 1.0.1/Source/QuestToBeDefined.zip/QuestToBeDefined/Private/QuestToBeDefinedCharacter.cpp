// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "QuestToBeDefined.h"
#include "QuestToBeDefinedCharacter.h"
#include "QuestPlayerController.h"
#include "Runtime/MoviePlayer/Public/MoviePlayer.h"


//////////////////////////////////////////////////////////////////////////
// AQuestToBeDefinedCharacter

AQuestToBeDefinedCharacter::AQuestToBeDefinedCharacter()
	
{
	// Set size for collision capsule
	GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);

	// set our turn rates for input
	BaseTurnRate = 45.f;
	BaseLookUpRate = 45.f;
	
	// Don't rotate when the controller rotates. Let that just affect the camera.
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;
	
	// Configure character movement
	GetCharacterMovement()->bOrientRotationToMovement = true; // Character moves in the direction of input...	
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 54.0f, 0.0f); // ...at this rotation rate 54 is a test
	GetCharacterMovement()->JumpZVelocity = 600.f;
	GetCharacterMovement()->AirControl = 0.2f;

	// Create a camera boom (pulls in towards the player if there is a collision)
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
	CameraBoom->TargetArmLength = 300.0f; // The camera follows at this distance behind the character	
	CameraBoom->bUsePawnControlRotation = true; // Rotate the arm based on the controller
	
	// Create a follow camera
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->AttachToComponent(CameraBoom, FAttachmentTransformRules::KeepRelativeTransform); // Attach the camera to the end of the boom and let the boom adjust to match the controller orientation
	FollowCamera->bUsePawnControlRotation = false; // Camera does not rotate relative to arm
	
	// Create a collision sphere for unarmed combat, attached to the char. left hand for now
	LeftHandCollisionSphere = CreateDefaultSubobject<USphereComponent>(TEXT("LeftHandCollisionSphere"));
	LeftHandCollisionSphere->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepRelativeTransform);
	LeftHandCollisionSphere->SetRelativeLocation(FVector(10.0f, 69.0f, 130.0f));
	LeftHandCollisionSphere->SetSphereRadius(20.0f);

	// Create a detection sphere, to allow the player to pick up pickups
	PickupValidationSphere = CreateDefaultSubobject<USphereComponent>(TEXT("PickupValidationSphere"));
	PickupValidationSphere->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
	PickupValidationSphere->SetSphereRadius(100.0f);

	// Set up the static mesh component for the player's left hand active weapon
	P_LeftHandActWepMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("LeftHandActiveWeaponMesh"));
	P_LeftHandActWepMesh->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepRelativeTransform, FName("LeftHandWeapon"));
	P_LeftHandActWepMesh->SetWorldScale3D(FVector(0.2f, 0.2f, 0.2f));

	// Set up the skeletal mesh component for the player's right hand active weapon
	P_RightHandActWepSkelMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("RightHandActiveWeaponSkeletalMesh"));
	P_RightHandActWepSkelMesh->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepRelativeTransform, FName("WeaponEquippedRightHanded"));

	/* Set up the weapon statistics components for the player's left hand active weapon and 
	right hand active weapon, modify these stat. pieces to have blank weapons
	*/
	P_LeftHandActiveWeaponStats = CreateDefaultSubobject<UWeaponStatistics>(TEXT("LeftHandActiveWeaponStats"));
	P_RightHandActiveWeaponStats = CreateDefaultSubobject<UWeaponStatistics>(TEXT("RightHandActiveWeaponStats"));

	P_LeftHandActiveWeaponStats->ModifyWeaponStats(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "");
	P_RightHandActiveWeaponStats->ModifyWeaponStats(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "");

	// Also set up the statistics for the player's active armour, also to be modified later
	P_ActiveArmourStats = CreateDefaultSubobject<UArmourStatistics>(TEXT("ActiveArmourStats"));

	// Start this member var. off at 1.0, to indicate 100% movement speed
	PlayerMovementSpeedMultiplyer = 1.0f;

	// Set the fields at their default values
	// Change so that these values are loaded from a save file
	C_MaxHealth = 100.0f;
	C_Health = 100.0f;
	C_MinHealth = 0.0f;

	C_Energy = 100.0f;
	C_MaxEnergy = 100.0f;
	C_MinEnergy = 0.0f;

	// The player's default name is 'Unknown', for now
	C_Name = "Unknown";

	// The player is unarmed to start off with, this will be set upon starting the intro level
	// Not like this: (P_ActiveWeapon = "Unarmed";)

	// Get the default values
	DefaultMaxAccel = GetCharacterMovement()->MaxAcceleration;
	DefaultMaxWalkSpeed = GetCharacterMovement()->MaxWalkSpeed;

	// The default values at the moment for the player's movement speed and acceleration rate, while sprinting
	SprintMoveSpeedMod = 1.75f * DefaultMaxWalkSpeed;
	SprintAccelRateMod = 1.25f * DefaultMaxAccel;

	// The energy drain to the player per tick for sprinting
	SprintEnergyDrain = 0.1;

	// The Player character will not be sprinting when they spawn into a level
	bIsSprinting = false;

	// The Player character can't have interupted PIBot's intro upon spawning
	bPlayerInteruptedPIBotIntro = false;

	// The Player character can't have triggered PIBot's important message telling sequence either
	bPlayerHasTriggeredPIBotToSayImportantMessage = false;

	// The Player also cannot have interupted ComAd's intro sequence as well
	bPlayerInteruptedComAdIntro = false;

	// The player cannot melee to start off with, unless they so will it
	bWantsToMelee = false;

	// The player can wear armour though
	bCanWearArmour = true;

	/* The player is not carring anything on them when they begin QTBDIntro 
	and they have a maximum carrying mass of 50kg
	*/
	CurrentCarryingMass = 0.0f;
	MaximumCarryingMass = 50.0f;

	// Note: The skeletal mesh and anim blueprint references on the Mesh component (inherited from Character) 
	// are set in the derived blueprint asset named MyCharacter (to avoid direct content references in C++)
}

/** Set the player's name for the first time */
void AQuestToBeDefinedCharacter::FirstTimeSetName(FString NewName)
{
	if (NewName == "")
	{
		C_Name = "Unknown";
	}
	else
	{
		C_Name = NewName;
	}
}

// For the implementation of these BlueprintNativeEvents:
void AQuestToBeDefinedCharacter::NewGameBtnPressed_Implementation()
{

}

void AQuestToBeDefinedCharacter::IsAtMinHealth_Implementation()
{

}

/** Add an item to the player's backpack */
bool AQuestToBeDefinedCharacter::AddItemToBackpack(AQTBDItem* ItemToAdd)
{
	// The value to be returned
	bool bSuccess = false;

	if (ItemToAdd == NULL)
	{
		return bSuccess;
	}

	/* Only add the item if the item's mass does not cause the player's current carring mass of items/objects, 
	to be greater than the maximum carrying mass for the player
	*/
	if (CurrentCarryingMass + ItemToAdd->ItemMass <= MaximumCarryingMass)
	{
		CurrentCarryingMass += ItemToAdd->ItemMass;
		PlayerBackpack.Add(ItemToAdd);
		
		// Therefore, the player was able to obtain this item
		bSuccess = true;
		return bSuccess;
	}
	// The player was not able to obtain this item if this is instead the case
	else if (CurrentCarryingMass + ItemToAdd->ItemMass > MaximumCarryingMass)
	{
		bSuccess = false;
		return bSuccess;
	}

	return bSuccess;
}

/** Remove a single item from the player's backpack */
void AQuestToBeDefinedCharacter::RemoveItemFromBackpack(AQTBDItem* ItemToRemove)
{
	// Remove the mass of the item from the player's current carrying mass first
	CurrentCarryingMass -= ItemToRemove->ItemMass;

	// Then, remove the item from the player's backpack
	PlayerBackpack.RemoveSingle(ItemToRemove);
}

/** Is the item to be found, in the player's backpack? */
bool AQuestToBeDefinedCharacter::IsItemInBackpack(AQTBDItem* ItemToFind)
{
	return PlayerBackpack.Contains(ItemToFind);
}

/** Modify the player's active weaponstats, to NewActiveWeapon's stats */
void AQuestToBeDefinedCharacter::ModActWep(UWeaponStatistics* NewActiveWeapon)
{
	/* 
		If this weapon is valid, requires the right hand weapon slot though,
		modify their right hand weapon statistics, otherwise, modify their left hand weapon statistics
	*/
	
	if (NewActiveWeapon != nullptr)
	{
		if (NewActiveWeapon->bRequiresRightArm == true)
		{
			P_RightHandActiveWeaponStats = NewActiveWeapon;
		}
		else
		{
			P_LeftHandActiveWeaponStats = NewActiveWeapon;
		}
	}	
}

/** Modify the player's active armour's stats, to NewActiveArmour's stats */
void AQuestToBeDefinedCharacter::ModActArm(UArmourStatistics* NewActiveArmour)
{
	if (NewActiveArmour != nullptr)
	{
		P_ActiveArmourStats = NewActiveArmour;
	}
}

/** If the player has a will to melee, set this flag to true */ 
void AQuestToBeDefinedCharacter::HasWillToMelee()
{
	bWantsToMelee = true;
}

/** If the player does not have a will to melee, or the time melee is active for has run out, set this flag to false */
void AQuestToBeDefinedCharacter::NoWillToMelee()
{
	bWantsToMelee = false;
}


/** Call to set this flag to true, whenever the player has interupted PIBot's intro */
void AQuestToBeDefinedCharacter::InteruptPIBotIntro()
{
	bPlayerInteruptedPIBotIntro = true;
}

/** Call to set this flag to true, whenever the player has triggered PIBot's important message sequence */
void AQuestToBeDefinedCharacter::TriggerPIBotsImportantMsgSequence()
{
	bPlayerHasTriggeredPIBotToSayImportantMessage = true;
}

/** Called whenever ComAd's intro sequence is interupted */
void AQuestToBeDefinedCharacter::InteruptComAdIntro()
{
	bPlayerInteruptedComAdIntro = true;
}

void AQuestToBeDefinedCharacter::NowInMainMenu()
{
	// Change this camera to rotate to look at the main menu (default starting level)

	FVector MainMenuLookAtLoc = FVector(0, 0, 0);
	FRotator RotToLookAtMainMenu = FRotator(0, 180, 0);

	FollowCamera->SetRelativeLocationAndRotation(MainMenuLookAtLoc, RotToLookAtMainMenu);

	// Get the player controller, then enable cinematic mode and disable their input for now, as they are in the main menu (default starting level)
	AQuestPlayerController* PlayerController = Cast<AQuestPlayerController>(UGameplayStatics::GetPlayerController(this, 0));
	PlayerController->SetCinematicMode(true, true, true);

	/* This does not work at the moment, bugs, wait for Epic to fix
	FLoadingScreenAttributes LoadingScreen;
	LoadingScreen.bAutoCompleteWhenLoadingCompletes = false;
	LoadingScreen.bMoviesAreSkippable = true;
	LoadingScreen.MoviePaths.Add(TEXT("Default_Startup"));
	GetMoviePlayer()->SetupLoadingScreen(LoadingScreen);
	GetMoviePlayer()->PlayMovie();
	*/ 
}

/** Do what is required for when the player is now in QTBDIntro */
void AQuestToBeDefinedCharacter::NowInQTBDIntro()
{
	// Set the camara back to its default relative rotation
	FVector DefaultLookAtLoc = FVector(0, 0, 0);
	FRotator DefaultLookAtRot = FRotator(0, 0, 0);

	FollowCamera->SetRelativeLocationAndRotation(DefaultLookAtLoc, DefaultLookAtRot);

	// Get the player controller, then disable cinematic mode, as they are now in the first level (QTBDIntro)
	AQuestPlayerController* PlayerController = Cast<AQuestPlayerController>(UGameplayStatics::GetPlayerController(this, 0));

	PlayerController->SetCinematicMode(false, false, false);
}

/** Handle enabling of Cinematic mode for the player, at certain points, the function immedietaly below can cause execution breaks to occur involenterily*/
void AQuestToBeDefinedCharacter::EnablePlayerCinematicMode()
{
	// Get the player controller, then call the 'SetCinematicMode' function with all inputs as true
	AQuestPlayerController* PlayerController = Cast<AQuestPlayerController>(UGameplayStatics::GetPlayerController(this, 0));
	
	PlayerController->SetCinematicMode(true, true, true);
}

void AQuestToBeDefinedCharacter::DisablePlayerCinematicMode()
{
	// Get the player controller, then call the 'SetCinematicMode' function with the first input as false, the rest as true
	AQuestPlayerController* PlayerController = Cast<AQuestPlayerController>(UGameplayStatics::GetPlayerController(this, 0));
	PlayerController->SetCinematicMode(false, true, true);
}

/** Set up all of the key binding settings for the player's input */
void AQuestToBeDefinedCharacter::SetupPlayerInputComponent(class UInputComponent* InputComponent)
{
	// Set up gameplay key bindings
	check(InputComponent);
	InputComponent->BindAction("Jump", IE_Pressed, this, &ACharacter::Jump);
	InputComponent->BindAction("Jump", IE_Released, this, &ACharacter::StopJumping);
	InputComponent->BindAction("DamageSelf", IE_Pressed, this, &AQuestToBeDefinedCharacter::DamageSelf);
	InputComponent->BindAction("Sprint", IE_Pressed, this, &AQuestToBeDefinedCharacter::HandleSprinting);


	// Movement bindings
	InputComponent->BindAxis("MoveForward", this, &AQuestToBeDefinedCharacter::MoveForward);
	InputComponent->BindAxis("MoveRight", this, &AQuestToBeDefinedCharacter::MoveRight);

	// We have 2 versions of the rotation bindings to handle different kinds of devices differently
	// "turn" handles devices that provide an absolute delta, such as a mouse.
	// "turnrate" is for devices that we choose to treat as a rate of change, such as an analog joystick
	InputComponent->BindAxis("Turn", this, &APawn::AddControllerYawInput);
	InputComponent->BindAxis("TurnRate", this, &AQuestToBeDefinedCharacter::TurnAtRate);
	InputComponent->BindAxis("LookUp", this, &APawn::AddControllerPitchInput);
	InputComponent->BindAxis("LookUpRate", this, &AQuestToBeDefinedCharacter::LookUpAtRate);
	
	// handle touch devices
	InputComponent->BindTouch(IE_Pressed, this, &AQuestToBeDefinedCharacter::TouchStarted);
	InputComponent->BindTouch(IE_Released, this, &AQuestToBeDefinedCharacter::TouchStopped);
	// Bind keys
}

void AQuestToBeDefinedCharacter::TouchStarted(ETouchIndex::Type FingerIndex, FVector Location)
{
	// jump, but only on the first touch
	if (FingerIndex == ETouchIndex::Touch1)
	{
		Jump();
	}
}

void AQuestToBeDefinedCharacter::TouchStopped(ETouchIndex::Type FingerIndex, FVector Location)
{
	if (FingerIndex == ETouchIndex::Touch1)
	{
		StopJumping();
	}
}

void AQuestToBeDefinedCharacter::TurnAtRate(float Rate)
{
	// calculate delta for this frame from the rate information
	AddControllerYawInput(Rate * BaseTurnRate * GetWorld()->GetDeltaSeconds());
}

void AQuestToBeDefinedCharacter::LookUpAtRate(float Rate)
{
	// calculate delta for this frame from the rate information
	AddControllerPitchInput(Rate * BaseLookUpRate * GetWorld()->GetDeltaSeconds());
}

float AQuestToBeDefinedCharacter::GetCurrentMoveSpeedMultiplyer()
{
	return PlayerMovementSpeedMultiplyer; 
}

/** Modify the player's current multiplyer to their movement speed */
void AQuestToBeDefinedCharacter::ModifyCurrMoveSpdMulti(float NewMovementSpeedMulti)
{
	PlayerMovementSpeedMultiplyer = NewMovementSpeedMulti;

	// One validation check for now, as the multiplyer cannot be negative
	if (PlayerMovementSpeedMultiplyer <= 0)
	{
		PlayerMovementSpeedMultiplyer = 1;
	}
}

/** Execute what is required to move along the characters forward axis */
void AQuestToBeDefinedCharacter::MoveForward(float Value)
{
	if ((Controller != NULL) && (Value != 0.0f))
	{
		// Adjust the Value by the PlayerSpeedMultiplyer first
		Value *= PlayerMovementSpeedMultiplyer;

		// find out which way is forward
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);

		// get forward vector
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		AddMovementInput(Direction, Value);
	}
}

/** Toggle sprinting on or off as required, this function is called whenever the player presses the left shift key */
void AQuestToBeDefinedCharacter::HandleSprinting()
{
	// Check to see if the player is currently sprinting
	// If so, they stop sprinting
	if (bIsSprinting)
	{
		bIsSprinting = false;
		GetCharacterMovement()->MaxWalkSpeed = DefaultMaxWalkSpeed;
		GetCharacterMovement()->MaxAcceleration = DefaultMaxAccel;
	}
	// Currently a test at the moment, toggle sprinting on
	// This will make the Player move faster and accelerate faster
	else if (!bIsSprinting && C_Energy > C_MinEnergy)
	{
		bIsSprinting = true;
		GetCharacterMovement()->MaxWalkSpeed = SprintMoveSpeedMod;
		GetCharacterMovement()->MaxAcceleration = SprintAccelRateMod;
	}

	// If the player's energy is at the minimum level for them, stop them sprinting
	if (C_Energy == C_MinEnergy)
	{
		bIsSprinting = false;
		GetCharacterMovement()->MaxWalkSpeed = DefaultMaxWalkSpeed;
		GetCharacterMovement()->MaxAcceleration = DefaultMaxAccel;
	}
}

void AQuestToBeDefinedCharacter::MoveRight(float Value)
{
	if ((Controller != NULL) && (Value != 0.0f))
	{
		// Adjust the Value by the PlayerSpeedMultiplyer first
		Value *= PlayerMovementSpeedMultiplyer;

		// find out which way is right
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);
	
		// get right vector 
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
		// add movement in that direction
		
		AddMovementInput(Direction, Value);
	}
}

/** Do damage to the player's health via themselves */
void AQuestToBeDefinedCharacter::DamageSelf()
{
	// Used to get the random amount of damage that will be done to the player
	FRandomStream* RNG = new FRandomStream();
	float DamageDone = 0.0f;

	// Make it so that random numbers will not be generated in the same order every time
	RNG->GenerateNewSeed();

	// Do a small, random amount of damage to the player
	// The next function will negate this value
	DamageDone = RNG->FRandRange(10, 20);

	DamageCharacter(DamageDone);
}

/** Modify the damage done to the player as required, then make a call to the super class function */
void AQuestToBeDefinedCharacter::DamageCharacter(float DamageValue)
{
	// Reduce the armour's durability first of all
	P_ActiveArmourStats->ReduceArmourDurability(DamageValue);

	// Then mitigate the damage, due to the armour's protection
	DamageValue -= DamageValue * P_ActiveArmourStats->DmgResistance;
	
	Super::DamageCharacter(DamageValue);
}

/** Used to modify this character's health /.
Put in a positive value to increase it, a negative value to decrease it*/
void AQuestToBeDefinedCharacter::ModifyHealth(float HealthChangeValue)
{
	// Call super first, to handle changing the player's health and doing a few other validation checks
	Super::ModifyHealth(HealthChangeValue);

	// Put the player char in cinematic mode (Removing their HUD from their viewport, is done by the PlayerHUD Blueprint)
	if (C_Health == C_MinHealth)
	{
		AQuestPlayerController* PlayerController = Cast<AQuestPlayerController>(Controller);

		DisableInput(PlayerController);

		PlayerController->SetCinematicMode(true, true, true); // enable cinematic mode,

		// Fire off this event
		IsAtMinHealth();
	}
}

/** Same here for this character's energy */
void AQuestToBeDefinedCharacter::ModifyEnergy(float EnergyChangeValue)
{
	C_Energy += EnergyChangeValue;

	// Check to make sure the player's energy is between the minimum and maximum values
	// Change it to be the minimum or maximum value if it is less than, or greater than those values

	if (C_Energy <= C_MinEnergy)
	{
		C_Energy = C_MinEnergy;
		bIsSprinting = false; // As the Player cannot sprint when they are at their minimum energy level
	}
	else if (C_Energy >= C_MaxEnergy)
	{
		C_Energy = C_MaxEnergy;
	}
}

// For updating every frame
void AQuestToBeDefinedCharacter::Tick(float DeltaSeconds)
{
	// Changed only if the player's active weapon is BrickWeapon
	FVector CurrentPlayerLocation = GetActorLocation();

	// Check if the character is sprinting and drain their energy if they are
	// If they run out of energy, they stop sprinting, while they are not sprinting, their energy recharges
	if (bIsSprinting)
	{
		ModifyEnergy(-SprintEnergyDrain);
	}
	else if (!bIsSprinting)
	{
		ModifyEnergy(SprintEnergyDrain);
	}
	
	// If the player's energy is at the minimum level for them, stop them sprinting
	if (C_Energy == C_MinEnergy)
	{
		bIsSprinting = false;

		ModifyEnergy(SprintEnergyDrain);
		GetCharacterMovement()->MaxWalkSpeed = DefaultMaxWalkSpeed;
		GetCharacterMovement()->MaxAcceleration = DefaultMaxAccel;
	}

	/*
	// If the player's active weapon is BrickWeapon, make it move with them, making sure to disable physics
	if (P_LeftHandActiveWeapon->ItemName == "BrickWeapon")
	{
		FVector FinalBrickLocation;
		
		// Offset the final location of the brick by these values, leaving Y the same
		FinalBrickLocation.X = CurrentPlayerLocation.X + 100.0f;
		FinalBrickLocation.Y = CurrentPlayerLocation.Y;
		FinalBrickLocation.Z = CurrentPlayerLocation.Z + 50.0f;

		P_LeftHandActiveWeapon->SetActorLocation(FinalBrickLocation);
		
		// Rotate the brick as well, to make sure it will be thrown forward
		//P_LeftHandActiveWeapon->SetActorRotation(FRotator(-90, 0, 0));
	}
	*/
}