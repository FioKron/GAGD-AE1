// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "PoorBodyArmour.h"

APoorBodyArmour::APoorBodyArmour()
	
{
	// Set up the member variables for this piece of armour
	ItemName = "Poor Body Armour";
	DamageResistance = 0.05f;
	ArmourDurability = 100.0f;
	MoveSpeedModification = 0.15f;

	ItemValue = 75.0f;
	ItemMass = 10.0f;
	
	// Also initilize the statistics for this piece of armour
	ArmourStats = CreateDefaultSubobject<UArmourStatistics>(TEXT("ArmourStats"));
	ArmourStats->ModifyArmStats(ItemName, DamageResistance, ArmourDurability, MoveSpeedModification);
}


