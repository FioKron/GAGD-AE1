// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "SacramentoController.h"

/** This constructor has no function other than creating itself to be used as an AIController, subject to change */
ASacramentoController::ASacramentoController()
	
{

}


