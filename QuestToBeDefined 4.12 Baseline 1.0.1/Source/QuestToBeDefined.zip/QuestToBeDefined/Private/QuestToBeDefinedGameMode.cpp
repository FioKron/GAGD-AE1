// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.
#include "QuestToBeDefined.h"
#include "QuestToBeDefinedGameMode.h"

AQuestToBeDefinedGameMode::AQuestToBeDefinedGameMode()
	
{
	// The name of the default current level, will be 'MainMenu'
	CurrentLevelName = FName("MainMenu");

	// Set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/Blueprints/MyCharacter"));
	if (PlayerPawnBPClass.Class != NULL)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}
	
	// Set up the player controller for this gamemode to be QuestPlayerController
	static ConstructorHelpers::FObjectFinder<UBlueprint> QuestPCOb(TEXT("Blueprint'/Game/Blueprints/QuestPlayerController.QuestPlayerController'"));
	if (QuestPCOb.Object != NULL)
	{
		PlayerControllerClass = (UClass*)QuestPCOb.Object->GeneratedClass;
	}
}

/** Perform the nessescary validation for changing the CurrentLevelName member variable */ 
bool AQuestToBeDefinedGameMode::ModifyCurrentLevelName(FName NewCurrentLevelName)
{
	// The variable for whether modifying CurrentLevel was successful or not, after validation of the input, to be returned from this function
	bool bModificationSuccess;

	if (NewCurrentLevelName == "MainMenu" || NewCurrentLevelName == "QTBDIntro")
	{
		CurrentLevelName = NewCurrentLevelName;
		bModificationSuccess = true;
	}
	else
	{
		bModificationSuccess = false;
	}

	return bModificationSuccess;
}



