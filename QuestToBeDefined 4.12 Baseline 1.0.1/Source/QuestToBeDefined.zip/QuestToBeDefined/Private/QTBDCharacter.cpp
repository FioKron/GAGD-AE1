// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "QTBDCharacter.h"

// Initilise this character:
AQTBDCharacter::AQTBDCharacter()	
{
	bIsAlive = true;
}

/** Set the relative rotation of this character, so that they are always perpendicular to the ground */
void AQTBDCharacter::KeepPerpendicularToGround()
{
	FRotator PerpToGround = GetActorRotation();
	SetActorRelativeRotation(FRotator(0, PerpToGround.Yaw, PerpToGround.Roll));
}

/** Trim the proceeding and trailing characters from ToBeTrimmed, then return this value */
FText AQTBDCharacter::CompleteTextTrim(FText ToBeTrimmed)
{
	ToBeTrimmed = ToBeTrimmed.TrimPrecedingAndTrailing(ToBeTrimmed);

	return ToBeTrimmed;
}

/** Get what direction is forward, from this particular character's point of view */
FRotator AQTBDCharacter::FindCharForwardDirection()
{	
	return GetActorQuat().GetForwardVector().ToOrientationRotator();
}

/*
	Return any of the values for this character's fields, if the values are valid:
*/

float AQTBDCharacter::GetHealth()
{
	if (C_Health != NULL)
	{
		return C_Health;
	}
	else
	{ // Do change these to something else
		return NULL;
	}
}

float AQTBDCharacter::GetEnergy()
{
	if (C_Energy != NULL)
	{
		return C_Energy;
	}
	else
	{
		return NULL;
	}
}

float AQTBDCharacter::GetMaxHealth()
{
	if (C_MaxHealth != NULL)
	{
		return C_MaxHealth;
	}
	else
	{
		return NULL;
	}
}

float AQTBDCharacter::GetMinHealth()
{
	if (C_MinHealth != NULL)
	{
		return C_MinHealth;
	}
	else
	{
		return NULL;
	}
}

float AQTBDCharacter::GetMinEnergy()
{
	if (C_MinEnergy != NULL)
	{
		return C_MinEnergy;
	}
	else
	{
		return NULL;
	}
}

float AQTBDCharacter::GetMaxEnergy()
{
	if (C_MaxEnergy != NULL)
	{
		return C_MaxEnergy;
	}
	else
	{
		return NULL;
	}
}

void AQTBDCharacter::DamageCharacter(float DamageValue)
{
	// Negate the value to deal damage to this character
	DamageValue = -DamageValue;

	// Modify this character's health by DamageValue
	ModifyHealth(DamageValue);
}


/** Used to modify this character's health.
Provide a positive value to increase it, or a negative value to decrease it */
void AQTBDCharacter::ModifyHealth(float HealthChangeValue)
{
	C_Health += HealthChangeValue;

	// Check to make sure this character's health is between the minimum and maximum values
	// Change it to be the minimum or maximum value if it is less than, or greater than those values
	if (C_Health <= C_MinHealth)
	{
		C_Health = C_MinHealth;

		// They are no longer alive in this case
		bIsAlive = false;
	}
	else if (C_Health >= C_MaxHealth)
	{
		C_Health = C_MaxHealth;
	}
}