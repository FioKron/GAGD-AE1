// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "PrivateMatterson.h"

APrivateMatterson::APrivateMatterson()
	
{
	// Rotate when the AI controller wants to rotate Matterson
	bUseControllerRotationPitch = true;
	bUseControllerRotationYaw = true;
	bUseControllerRotationRoll = true;

	// Configure character movement
	GetCharacterMovement()->bOrientRotationToMovement = true; // Character moves in the direction of input...	
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 54.0f, 0.0f); // ...at this rotation rate 54 is a test
	GetCharacterMovement()->JumpZVelocity = 600.f;
	GetCharacterMovement()->AirControl = 0.2f;

	// Set up the character member variables
	C_Name = "Pvt. Matterson";

	Matt_ActiveWeaponStats = CreateDefaultSubobject<class UWeaponStatistics>(TEXT("Matt_RightHandActiveWeaponStats"));
	Matt_ActiveArmourPieceStats = CreateDefaultSubobject<class UArmourStatistics>(TEXT("Matt_ActiveArmourPieceStats"));

	C_MaxHealth = 100.0f;
	C_Health = 100.0f;
	C_MinHealth = 0.0f;

	C_MaxEnergy = 100.0f;
	C_Energy = 100.0f;
	C_MinEnergy = 100.0f;

	// Make sure that Matterson is in their initial state
	CurrentStatus = EPvtMattersonStatus::PMS_Idle;

	// Pvt. Matterson starts with some relativly poor armour 
	bCanWearArmour = true;

	// They will not have their rifle ready to start off with
	bHasRifleReady = false;

	// No other instance of Pvt. Matterson will have LOS to a target, just yet...
	bAnotherInstanceHasLOS = false;

	// No other instances will be blocking line of sight as well
	bLOSBlockedByAnotherInst = false;

	// It won't be time to equip their primary weapon yet either
	bTimeToEquipPrimary = false;
}

/** Inform this instance of Pvt. Matterson that it is time to equip their primary weapon */
void APrivateMatterson::EquipPrimaryWeapon()
{
	bTimeToEquipPrimary = true;
}

/** 
	Notify all other instances of Pvt. Matterson, that are in close enough proximity, that this one has line of sight
	@AActor* CloseProxActors: An array of actors that are in close proximity, these actors, after filtering,
	will be cast to APrivateMatterson
*/
void APrivateMatterson::NotifyOtherInstancesOfThisHavingLOS(TArray<AActor*> CloseProxActors)
{
	// Loop through all of the indicies of CloseProxActors and set 'AnotherInstanceHasLOS' to true
	for (int32 Counter = 0; Counter < CloseProxActors.Num(); Counter++)
	{
		APrivateMatterson* MattInst = Cast<APrivateMatterson, AActor>(CloseProxActors[Counter]);
		MattInst->bAnotherInstanceHasLOS = true;
	}
}

/** Modify the associated state flag to reflect Pvt. Matterson having their rifle ready */
void APrivateMatterson::ReadyToFireRifle()
{
	bHasRifleReady = true;
}

/** Modify the stats of Private Matterson's active weapon and armour, respectivly, in the two functions below: */
void APrivateMatterson::ModMattActWeaponStats(UWeaponStatistics* NewActiveWeapon)
{
	Matt_ActiveWeaponStats = NewActiveWeapon;
}

void APrivateMatterson::ModMattActArmourStats(UArmourStatistics* NewActiveArmour)
{
	Matt_ActiveArmourPieceStats = NewActiveArmour;
}

/** Modify Pvt. Matterson's health, when required */
void APrivateMatterson::ModifyHealth(float HealthChangeValue)
{
	// Call Super first
	Super::ModifyHealth(HealthChangeValue);

	// Pvt. Matterson has been defeated, do what is required to show them as such
	if (C_Health == C_MinHealth)
	{
		IsAtMinHealth();
	}
}

/** A modified version of DamageCharacter, to allow for Pvt. Matterson's armour, to mitigate any damage done */
void APrivateMatterson::DamageCharacter(float DamageValue)
{
	/* Similar to the player's version of this function, reduce Pvt. Matterson's armour piece's durability
	reduce the damage by the damage resistance of this armour piece, then deal damage to Pvt. Matterson */
	Matt_ActiveArmourPieceStats->ReduceArmourDurability(DamageValue);

	DamageValue -= DamageValue * Matt_ActiveArmourPieceStats->DmgResistance;
	
	// Finish off this function with a call to Super
	Super::DamageCharacter(DamageValue);
}

/** Return whether Pvt. Matterson is at minimum health*/
bool APrivateMatterson::IsPvtMattAtMinHeal()
{
	// The value to be returned
	bool bAtMinHealth = false;

	// Perform the required checks
	if (C_Health >= C_MinHealth)
	{
		bAtMinHealth =false;
		return bAtMinHealth;
	}
	else
	{
		bAtMinHealth = true;
		return bAtMinHealth;
	}

	// Return the above value at this point to
	return bAtMinHealth;
}

void APrivateMatterson::IsAtMinHealth_Implementation()
{

}
