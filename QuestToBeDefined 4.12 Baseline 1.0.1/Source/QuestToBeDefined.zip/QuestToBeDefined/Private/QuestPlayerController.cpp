// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "QuestPlayerController.h"


AQuestPlayerController::AQuestPlayerController()
	
{
	// Set this flag to true, as the player will have to use the mouse cursor for the main menu, the first 'level'
	bShowMouseCursor = true;
}

// Modify the player controller's mouse visibility as required
void AQuestPlayerController::SetCursorVisibility(bool bCursorVisibility)
{
	bShowMouseCursor = bCursorVisibility;
}
