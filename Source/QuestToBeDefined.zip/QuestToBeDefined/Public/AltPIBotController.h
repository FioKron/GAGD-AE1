// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QuestToBeDefined.h"
#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "PIBot.h"
#include "AltPIBotController.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AAltPIBotController : public AAIController
{
	GENERATED_BODY()

public:

	/** Get the controlled pawn of this controller, as a PIBot, the pawn should be PIBot, as this is what this controller will only control */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Controlled Pawn As PIBot"), Category = "PawnRetrival")
	APIBot* GetControlledPawnAsPIBot();

	/** The functions just below, can get any of PIBot's flags, which is what this controller will control */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Is First Encounter With Player"), Category = "FlagRetrival")
	bool GetIsFirstEncounterWithPlayer();

	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Player Is Near PIBot"), Category = "FlagRetrival")
	bool GetPlayerIsNearPIBot();

	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get PIBot Finished Intro"), Category = "FlagRetrival")
	bool GetPIBotFinishedIntro();

	/** This function will calculate whether PIBot has finished their intro sequence, and is standing upright */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Is PIBot Active"), Category = "FlagCheck")
	bool IsPIBotActive();

protected:
	AAltPIBotController();
};
