// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "QuestToBeDefined.h"
#include "WeaponStatistics.generated.h"

UCLASS()
class QUESTTOBEDEFINED_API UWeaponStatistics : public UActorComponent
{
	GENERATED_BODY()
	
public:	

	// All of the members of this actor match up to the members of QTBDWeapon and also uses one of the members from QTBDItem
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	float Damage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	bool bRequiresAmmo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	bool bIsGun;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	bool bRequiresRightArm;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	float InitAmmCnt;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	float MaxAmmCnt;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	float AmmPerLoadMech;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	float WeaponDelayBetweenAttacks;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	float WeaponReloadDelay;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = PublicWeaponFields)
	float CurrentAmmoInStorMech;

	/** Reduce the ammo count on firing the weapon by one, every time the weapon fires (whether this weapon is full/semi-auto. or single shot), if not a melee weapon of course */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Decrement ammo count for one ammo. used"), Category = Weapons)
	void DecrementCurrentAmmoCnt();

	/** Give this weapon an additional quantity of ammo
	@float AdditionalQuantity: The count of ammo. to add to this weapon's current ammo count, if the weapon uses ammo. */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Increase stored ammo. quantity"), Category = Weapons)
	void GiveWeaponAmmo(float AdditionalQuantity);

	/** After firing a shot, reduce the ammo. count in the storage mechanism of this weapon by 1, only if this weapon uses ammo. */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Decrement magazine ammunition count"), Category = MagazineManagement)
	void DecrementAmmoStorMechCnt();

	/** Replenish the storage mech. of this weapon completly, discarding unused ammo. Only do so if the weapon uses ammo */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Load ammo"), Category = MagazineManagement)
	void LoadNewAmmo();

	/** The weapon's name, as all the stats stored in this class are weapons, not just items */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = WeaponFields)
	FString WeaponName;

	/** Used to initilise the weapon, as well as modify this classes values when required, with one function call */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Initilise weapon statitics"), Category = Initilisation)
	void ModifyWeaponStats(float NewDmg, bool NewReqAmm, bool NewReqRigArm, bool NewIsGun, float NewInitAmmCnt, float NewMaxAmmCnt, float NewAmmPerLoadMech, float NewCurrAmmInLoadMech, float NewWepDelayBtwnAttk, float NewWepReDelay,FString NewWeaponName);

protected:

	// The default constructor, does nothing for now 
	UWeaponStatistics();
};
