// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "QuestToBeDefined.h"
#include "TargetDummy.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API ATargetDummy : public AActor
{
	GENERATED_BODY()

public:

	/** The Target Dummy's current health */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health")
	float CurrentHealth;

	/** Modify the Target Dummy's CurrentHealth */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Health"), Category = "Health")
	void ModifyHealth(float HealthValue);
	
	/** Get the Target Dummy's current health */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Current Health"), Category = "Health")
	float GetCurrentHealth();

	/** This event fires when this Target Dummy's health is at 0 */
	UFUNCTION(BlueprintNativeEvent, meta = (DisplayName= "Is At Zero Health"))
	void IsAtZeroHealth();

protected:

	// The default constructor 
	ATargetDummy();
};
