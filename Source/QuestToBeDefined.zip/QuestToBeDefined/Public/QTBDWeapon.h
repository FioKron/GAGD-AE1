// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QuestToBeDefined.h"
#include "GameFramework/Actor.h"
#include "QuestToBeDefined.h"
#include "QTBDItem.h"
#include "WeaponStatistics.h"
#include "QTBDWeapon.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AQTBDWeapon : public AQTBDItem
{
	GENERATED_BODY()
	
public:

	/** This weapon's damage */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	float WeaponDamage;

	/** Whether the weapon uses ammo or not */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	bool bUsesAmmo;

	/** The initial ammo for this weapon, which the player can see upon pickup */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	float InitialAmmoCount;

	/** The maximum ammo this weapon has */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	float MaximumAmmoCount;

	/** The ammuntion per storage mechanism of the weapon */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	float AmmoPerStorageMech;

	/** The current ammo. in the storage mech for this weapon. Starts off with full capacity, if the weapon uses ammo. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	float CurrentAmmoInStorMech;

	/** The delay in time that must pass, before the next attack with the weapon can be executed */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	float DelayUntilNextAttack;

	/** The time (in seconds) that it takes for the weapon to be reloaded, after using all of the ammo. in this weapon's loading mech. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	float WeaponReloadDuration;

	/** Whether this weapon is a firearm or not and so uses a skeletal mesh */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	bool bIsFirearm;

	/** Whether this weapon requires use of the player character's right arm weapon slot */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PublicItemFields)
	bool bRequiresRightArm;

	/** A store for all the stats of this weapon */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = WeaponStats)
	UWeaponStatistics* WeaponStats;

protected:

	// The default constructor 
	AQTBDWeapon();

};
