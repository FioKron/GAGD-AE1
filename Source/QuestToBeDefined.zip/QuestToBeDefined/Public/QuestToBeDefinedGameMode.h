// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.
#pragma once

#include "QuestToBeDefined.h"
#include "GameFramework/GameMode.h"
#include "QuestToBeDefinedCharacter.h"
#include "QuestPlayerController.h"
#include "Runtime/Engine/Classes/Engine/Blueprint.h"
#include "Kismet/GameplayStatics.h"
#include "BrickWeapon.h"
#include "QuestToBeDefinedGameMode.generated.h"

UCLASS(minimalapi)
class AQuestToBeDefinedGameMode : public AGameMode
{
	GENERATED_BODY()
	
public:

	/** The name of the current level (map), that the game has loaded into */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Maps)
	FName CurrentLevelName;

	/** 
		Modify the name of the CurrentLevelName pararmeter, when apropirate
	
		@Param: FName NewCurrentLevelName: The value to set CurrentLevelName to

		@Return: bool ModificationSuccess: For whether modifying CurrentLevelName was successful, after validation of the input
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Current Level Stored Name"), Category = Maps)
	bool ModifyCurrentLevelName(FName NewCurrentLevelName);

protected:

	AQuestToBeDefinedGameMode();
};



