// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDWeapon.h"
#include "QuestToBeDefined.h"
#include "Unarmed.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AUnarmed : public AQTBDWeapon
{
	GENERATED_BODY()

public:


protected:
	// The default constructor 
	AUnarmed();
};
