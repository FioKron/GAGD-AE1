// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QTBDArmour.h"
#include "Unarmoured.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AUnarmoured : public AQTBDArmour
{
	GENERATED_BODY()
	
protected:

	AUnarmoured();
	
};
