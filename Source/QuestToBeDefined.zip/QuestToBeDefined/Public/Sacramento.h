// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QuestToBeDefined.h"
#include "QTBDCharacter.h"
#include "WeaponStatistics.h"
#include "BrickWeapon.h"
#include "PrivateMatterson.h"
#include "PvtMattersonAssaultRifleBullet.h"
#include "SacramentosShotgunSlugProj.h"
#include "Sacramento.generated.h"

/**
 * 
 */

 /** This enum is for the current status of Sacramento, his state that is */
UENUM(BlueprintType) // "BlueprintType" is essential to include, according to Rama
enum class ESacramentoStatus : uint8
{
	SS_GiveIntro	 UMETA(DisplayName = "GiveIntroductionToPlayer"),
	SS_CheckLOS		 UMETA(DisplayName = "CheckIfCanSeeTarget"),
	SS_LOSBlocked	 UMETA(DisplayName = "CannotSeeTarget"),
	SS_HasLOS		 UMETA(DisplayName = "CanSeeTarget"),
	SS_Attacking	 UMETA(DisplayName = "AttackingTarget"),
	SS_Reloading	 UMETA(DisplayName = "RealoadingWeapon"),
	SS_AttackSuccess UMETA(DisplayName = "DestroyedTarget"),
	SS_Dead			 UMETA(DisplayName = "AtMinimumHealth")
};

UCLASS()
class QUESTTOBEDEFINED_API ASacramento : public AQTBDCharacter
{
	GENERATED_BODY()

public:
	
	/** The behaviour tree member for Sacramento; how Sacramento will behave in game */
	UPROPERTY(EditAnywhere, Category = Behaviour)
	class UBehaviorTree* SacramentoBehaviour;

	/** The initial location Sacramento should go to */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = InitCommand)
	FVector StartingLocation;
	
	/** The statistics of Sacramento's currently active weapon */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Weapons)
	UWeaponStatistics* Sac_ActiveWeaponStats;

	/** Sacramento's current status */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = State)
	ESacramentoStatus CurrentStatus;
	
	/** This flag is for whether or not Sacramento has their shotgun ready to fire */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = StateFlags)
	bool bHasShotgunReady;

	/** The flag for whether it is time for Sacramento to equip their primary weapon or not */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bIsTimeToEquipPrimary;

	/** The flag for whether Sacramento is reloading their primary weapon or not */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bReloadingPrimaryWeapon;

	/** This flag is for whether or not Sacramento has provided their introduction to the player, with some choices */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bHasGivenIntroduction;

	/** The flag for whether Sacramento should be hostile towards their default target, the player that is, such as the player running on ahead when they are giving their introduction */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bIsHostileTowardsDefaultTarget;

	/** Another flag for whether it is time for Sacramento to show their launcher to the player, as part of their plan */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bTimeToShowLauncherToPlayer;

	/** Another flag as well, for if Sacramento has shown the player their launcher, as part of their plan */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bHasShownPlayerLauncher;

	/** Similar to the above two flags, if Sacramento has stowed away their rocket launcher */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bHasStowedRocketLauncher;

	/** For whether Sacramento should inform the player of certain controllable elements of his plan */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Flags)
	bool bTimeToDetailControlPartsPlan;

	/** This is the answer the player gives to Sacramento's introduction first question */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PlayerIntroQuestionAnswers)
	FString PlayersFirstIntroQuestionAnswer;

	/** This is the answer that the player gives to the question "So you won't mind staying then, will you?" */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = PlayerIntroQuestionAnswers)
	FString PlayersWontMindStayingQuestionAnswer;

	/** If it is time to show the player their launcher, modify the associated flag to true */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Is now time to show the player their Rocket Launcher"), Category = FlagModification)
	void IsNowTimeToShowLauncherToPlayer();

	/** If Sacramento has shown the player their launcher, it is no longer time to show it and so, set the associated flag to false */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "No longer time to show the player their Rocket Launcher"), Category = FlagModification)
	void NoLongerTimeToShowLauncher();

	/** If Sacramento has shown the player their launcher already, modify the associated flag to true */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Sacramento has now shown the player their Rocket Launcher"), Category = FlagModification)
	void HasNowShownPlayerLauncher();

	/** Similar to the above two functions, set the associated flag to true */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Sacramento has now stowed their Rocket Launcher"), Category = FlagModification)
	void HasNowStowedRocketLauncher();

	/** To be called after the player answers Sacramento's first question in their introduction dialog */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Player's first introduction question answer"), Category = Analysis)
	FString GetPlayersFirstIntroQuestionAnswer(FString PlayersAnswer);

	/** To be called after the player answers Sacramento's "So you won't mind staying then, will you?" question in their introduction dialog */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Get Player's won't mind staying introduction question answer"), Category = Analysis)
	FString GetPlayersWontMindStayingIntroQuestionAnswer(FString PlayersAnswer);

	/** Inform Sacramento that it is now time to detail controllable elements of his plan to the player */
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Detail controllable elements of plan"), Category = FlagModification)
	void TimeToDetailControlablePartsPlanToPlayer();

	/** Called whenever Sacramento is hostile towards their target, for whatever reason */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Sacramento is now hostile towards their target"), Category = FlagModification)
	void SacramentoNowHostileTowardsTarget();

	/** To be called after Sacramento has provided the player with their introduction, completly */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Sacramento has now given their introduction"), Category = FlagModification)
	void HasNowGivenIntroduction();

	/** The following two functions are for setting the ReloadingPrimaryWeapon flag to true and false, respectivly */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Time for Sacramento to reload their primary"), Category = FlagModification)
	void NowReloadingPrimaryWeapon();

	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Sacramento has finish reloading their primary"), Category = FlagModification)
	void NotReloadingPrimaryWeapon();

	/** Inform Sacramento that it is time to equip their primary weapon */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Equip Sacramento's primary weapon"), Category = FlagModification)
	void TimeToEquipPrimary();

	/** Check if Sacramento is at their minimum health */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Is Sacramento at their minimum health?"), Category = Health)
	bool IsSacramentoAtMinHeal();

	/** An event for Blueprint to use, called should Sacramento be at minimum health, in the ModifyHealth function */
	UFUNCTION(BlueprintNativeEvent, meta = (DisplayName= "Sacramento is at their minimum health"), Category = Health)
	void IsAtMinHealth();

	/** Modify HasShotgunReady to show that this is the case */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Sacramento has their shotgun ready to fire"), Category = Weapons)
	void ReadyToFireShotgun();
	
	/** Modify Sacramento's left hand active weapon, statwise
	@UWeaponStats NewActiveWeapon: The weapon stats associated with Sacramento's newly equipped weapon
	*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Modify Active Weapon"), Category = ActiveWeapon)
	void ModLeftHandActWepStats(UWeaponStatistics* NewActiveWeaponStats);

	/** Give Sacramento their initial target location, call this function upon spawning Sacramento into a level 
	@FVector InitTargetLocal: The vector of the initial location for Sacramento to go to */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Give initial target location"), Category = InitCommand)
	void InitiliseTargetLocation(FVector InitTargetLocal);

protected:

	/** A slight alteration to the ModifyHealth function of the super class */
	void ModifyHealth(float HealthChangeValue)override;

	/** New version of the constructor, for Sacramento */
	ASacramento();

};
