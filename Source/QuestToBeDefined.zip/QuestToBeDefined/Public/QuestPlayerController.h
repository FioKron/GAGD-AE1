// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "QuestToBeDefined.h"
#include "GameFramework/PlayerController.h"
#include "QuestPlayerController.generated.h"

/**
 * 
 */
UCLASS()
class QUESTTOBEDEFINED_API AQuestPlayerController : public APlayerController
{
	GENERATED_BODY()

public:


	/** Modify the visiblity of the player's cursor on the HUD, typically a mouse cursor */
	UFUNCTION(BlueprintCallable, meta = (DisplayName= "Set cursor visibility"), Category = ModifyHUDElement)
	void SetCursorVisibility(bool bCursorVisibility);

protected:
	AQuestPlayerController();
};
