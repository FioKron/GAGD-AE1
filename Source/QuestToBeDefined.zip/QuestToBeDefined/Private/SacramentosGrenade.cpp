// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "SacramentosGrenade.h"

/** 
	This is simply a grenade from the Player's point of view, have Sacramento complain about/comment on
	the Player picking this up
*/
ASacramentosGrenade::ASacramentosGrenade()
{
	// Set the name of this weapon
	ItemName = "Grenade";

	// As well as its mass and value
	ItemMass = 1.0f;
	ItemValue = 200.0f;

	// At the moment, 100 damage for this weapon, for testing, subject to change
	WeaponDamage = 100.0f;

	// Set up this weapon's use of ammo
	bUsesAmmo = true;

	// It is not a gun though
	bIsFirearm = false;

	// It also does not require the right hand weapon slot
	bRequiresRightArm = false;

	// As well as how ammo is handled for this weapon, as there is 1 brick here, 1 for all of these vars
	InitialAmmoCount = 1.0f;
	MaximumAmmoCount = 1.0f;
	AmmoPerStorageMech = 1.0f;
	CurrentAmmoInStorMech = 1.0f;

	/* As this weapon has an ammo. Count of one, it does not require reloading and there is no delay between picking it up and throwing it, 
	can only be picked up and thrown once though, then it explodes */
	WeaponReloadDuration = 0.0f;
	DelayUntilNextAttack = 0.0f;

	// Set up the weapon statistics member var. To get the stats of this weapon when required
	WeaponStats = CreateDefaultSubobject<UWeaponStatistics>(TEXT("WeaponStats"));
	WeaponStats->ModifyWeaponStats(WeaponDamage, bUsesAmmo, bRequiresRightArm, bIsFirearm, InitialAmmoCount, MaximumAmmoCount, AmmoPerStorageMech, CurrentAmmoInStorMech, DelayUntilNextAttack, WeaponReloadDuration, ItemName);

	// Set up the fuse handling for this grenade
	
	// 5 seconds till explosion, testing value
	TimeTillExplosion = 5.0f;

	bGrenadeIsPrimed = false;

	// This grenade is an actor that is tickable
	PrimaryActorTick.bCanEverTick = true;
}

/** Prime this grenade for detonation */
void ASacramentosGrenade::PrimeGrenade()
{
	bGrenadeIsPrimed = true;
}

/** Perform the required checks per frame for this grenade */
void ASacramentosGrenade::Tick(float DeltaSeconds)
{
	// Call the parent Tick function
	Super::Tick(DeltaSeconds);

	if (bGrenadeIsPrimed)
	{
		TimeTillExplosion -= DeltaSeconds;

		// When TimeTillExplosion is 0, have blueprint handle the explosion of this grenade
		if (TimeTillExplosion <= 0.0f)
		{
			TimeTillExplosion = 0.0f;

			TimeForExplosion();
		}
	}
}
