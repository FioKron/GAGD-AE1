// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "MachinePistol.h"

/** Set up this weapon with the correct statistical values */
AMachinePistol::AMachinePistol()
	
{
	// Set the name of this weapon
	ItemName = "Light Machine Pistol";

	// At the moment, 14 damage for this weapon, subject to change (for balance, test later)
	WeaponDamage = 10.0f;

	// Setup this weapon's use of ammo
	bUsesAmmo = true;

	// This wepaon is also a gun
	bIsFirearm = true;

	// This machine pistol does require the use of the right arm weapon slot
	bRequiresRightArm = true;

	// As well as how ammo is handled for this weapon, 30 bullets can be loaded, Pvt. Matterson also has a decent quantity of bullets
	InitialAmmoCount = 300.0f;
	MaximumAmmoCount = 300.0f;
	AmmoPerStorageMech = 20.0f;
	CurrentAmmoInStorMech = AmmoPerStorageMech;

	// Delay between attacks and time that it takes for this weapon to be reloaded are subject to balance, test values for now
	DelayUntilNextAttack = 0.2330f; // 
	WeaponReloadDuration = 3.40f; // Similarary, this is the time that it takes for the reload animation to be completed

	// Set up the weapon statistics member var. to get the stats of this weapon when required
	WeaponStats = CreateDefaultSubobject<UWeaponStatistics>(TEXT("WeaponStats"));
	WeaponStats->ModifyWeaponStats(WeaponDamage, bUsesAmmo, bRequiresRightArm, bIsFirearm, InitialAmmoCount, MaximumAmmoCount, AmmoPerStorageMech, CurrentAmmoInStorMech, DelayUntilNextAttack, WeaponReloadDuration, ItemName);;
}



