// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "WeaponStatistics.h"

// This constructor is required for actors 
UWeaponStatistics::UWeaponStatistics()
{

}

void UWeaponStatistics::ModifyWeaponStats(float NewDmg, bool NewReqAmm, bool NewReqRigArm, bool NewIsGun, float NewInitAmmCnt, float NewMaxAmmCnt, float NewAmmPerLoadMech, float NewCurrAmmInLoadMech, float NewWepDelayBtwnAttk, float NewWepReDelay, FString NewWeaponName)
{
	// Setup this function class for weapon stat storage, init. the values of this class, to that of the particular QTBDWeapon of which this class will be a member

	Damage = NewDmg;
	bRequiresAmmo = NewReqAmm;
	bIsGun = NewIsGun;
	bRequiresRightArm = NewReqRigArm;
	InitAmmCnt = NewInitAmmCnt;
	MaxAmmCnt = NewMaxAmmCnt;
	AmmPerLoadMech = NewAmmPerLoadMech;
	CurrentAmmoInStorMech = NewCurrAmmInLoadMech;
	WeaponDelayBetweenAttacks = NewWepDelayBtwnAttk;
	WeaponReloadDelay = NewWepReDelay;
	WeaponName = NewWeaponName;
}


/** Reduce the current ammo. count by one, validation to make sure that the current ammo. count does not go below 0 */
void UWeaponStatistics::DecrementCurrentAmmoCnt()
{
	// In addition, if the weapon does not use ammo, return out of this function, else, carry on
	if (bRequiresAmmo == false)
	{
		return;
	}
	else
	{
		InitAmmCnt--;

		if (InitAmmCnt <= 0)
		{
			InitAmmCnt = 0;
		}
	}
}

/** Give this weapon an additional quantity of ammo. Validation makes sure this does not go above the maximum ammo. count, or below it */
void UWeaponStatistics::GiveWeaponAmmo(float AdditionalQuantity)
{
	// In addition, if the weapon does not use ammo, return out of this function, else, carry on
	if (bRequiresAmmo == false)
	{
		return;
	}
	else
	{
		InitAmmCnt += AdditionalQuantity;

		if (InitAmmCnt >= MaxAmmCnt)
		{
			InitAmmCnt = MaxAmmCnt;
		}
		else if (InitAmmCnt <= 0)
		{
			InitAmmCnt = 0;
		}
	}
}

/** Reduce the count of the ammo. in this weapon's storage mechanism by 1,
also make sure that the weapon uses ammo, first and foremost
*/
void UWeaponStatistics::DecrementAmmoStorMechCnt()
{
	// Return out of this function if the weapon does not use ammo.
	if (bRequiresAmmo == false)
	{
		return;
	}
	else
	{
		// Otherwise, reduce the current ammo. in the storage mechanism by 1, then check if this value is 0
		CurrentAmmoInStorMech--;
	}
}

/** Load some more ammo. for this weapon, discarding the ammo that was not used before more ammo was loaded, if this weapon uses a magazine (add new mem. for such soon).
In addition, if the weapon does not use ammo, return out of this function, else, carry on
*/
void UWeaponStatistics::LoadNewAmmo()
{
	if (bRequiresAmmo == false)
	{
		return;
	}
	else
	{
		// Give the weapon a negitive quantity of ammo, equal to that of the current ammo in the storage mechanism
		GiveWeaponAmmo(-(CurrentAmmoInStorMech));

		// Then replenish the ammo in the weapon's storage mechanism
		CurrentAmmoInStorMech = AmmPerLoadMech;
	}
}