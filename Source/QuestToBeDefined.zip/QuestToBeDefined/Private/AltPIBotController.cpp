// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "AltPIBotController.h"


// Empty constructor, for now
AAltPIBotController::AAltPIBotController()
{

}

/** The 3 flag retrival functions */

bool AAltPIBotController::GetIsFirstEncounterWithPlayer()
{
	APIBot* ControlledPIBot = Cast<APIBot>(GetPawn());

	return ControlledPIBot->bFirstEncounterWithPlayer;
}

bool AAltPIBotController::GetPlayerIsNearPIBot()
{
	APIBot* ControlledPIBot = Cast<APIBot>(GetPawn());
	
	return ControlledPIBot->bPlayerIsNearPIBot;
}

bool AAltPIBotController::GetPIBotFinishedIntro()
{
	APIBot* ControlledPIBot = Cast<APIBot>(GetPawn());

	return ControlledPIBot->bIntroFinished;
}

/** Retrive the nessescary flag with one of the above 3 functions, then return the value of it, with this function */

bool AAltPIBotController::IsPIBotActive()
{
	bool bNowIntroFinished = GetPIBotFinishedIntro();

	// Return what this boolean statement checks
	return bNowIntroFinished;
}

/** Get the pawn of this controlller, than return this pointer cast to class PIBot */
APIBot* AAltPIBotController::GetControlledPawnAsPIBot()
{
	return Cast<APIBot>(GetPawn());
}