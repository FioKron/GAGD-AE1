// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "PrivateMattersonsAssaultRifle.h"

APrivateMattersonsAssaultRifle::APrivateMattersonsAssaultRifle()
	
{
	// Set the name of this weapon
	ItemName = "Matterson's Assault Rifle";

	// At the moment, 14 damage for this weapon, subject to change (for balance, test later)
	WeaponDamage = 14.0f;

	// Setup this weapon's use of ammo
	bUsesAmmo = true;

	// This weapon is also a gun
	bIsFirearm = true;

	// This weapon does require the right hand weapon slot
	bRequiresRightArm = true;

	// As well as how ammo is handled for this weapon, 30 bullets can be loaded, Pvt. Matterson also has a decent quantity of bullets
	InitialAmmoCount = 600.0f;
	MaximumAmmoCount = 600.0f;
	AmmoPerStorageMech = 30.0f;
	CurrentAmmoInStorMech = AmmoPerStorageMech;

	// Delay between attacks and time that it takes for this weapon to be reloaded are subject to balance, test values for now
	DelayUntilNextAttack = 0.2330f; // This is the time that the Rifle_Fire_W animation will take to play, hence this delay
	WeaponReloadDuration = 3.40f; // Similarary, this is the time that it takes for the reload animation to be completed

	// Set up the weapon statistics member var. To get the stats of this weapon when required
	WeaponStats = CreateDefaultSubobject<UWeaponStatistics>(TEXT("WeaponStats"));
	WeaponStats->ModifyWeaponStats(WeaponDamage, bUsesAmmo, bRequiresRightArm, bIsFirearm, InitialAmmoCount, MaximumAmmoCount, AmmoPerStorageMech, CurrentAmmoInStorMech, DelayUntilNextAttack, WeaponReloadDuration, ItemName);
}


