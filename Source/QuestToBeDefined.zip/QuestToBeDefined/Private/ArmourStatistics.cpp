// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "ArmourStatistics.h"


// Sets default values for this component's properties
UArmourStatistics::UArmourStatistics()
{

}

// Modify the member variables for this component, when required
void UArmourStatistics::ModifyArmStats(FString NewArmourName, float NewDmgResist, float NewArmrDura, float NewMovSpdMod)
{
	ArmName = NewArmourName;
	DmgResistance = NewDmgResist;
	ArmDurability = NewArmrDura;
	MovSpdMod = NewMovSpdMod;
}

/** Perform the nessescary actions for reducing this armour's durability */
void UArmourStatistics::ReduceArmourDurability(float IncomingDamage)
{
	// Reduce the durability of the armour to that of the damage absorbed by the armour 
	ArmDurability -= IncomingDamage * DmgResistance;

	// If the armour's durability is 0, as to is its damage resistance, until this armour piece gets repaired
	if (ArmDurability == 0.0f)
	{
		DmgResistance = 0.0f;
	}
}