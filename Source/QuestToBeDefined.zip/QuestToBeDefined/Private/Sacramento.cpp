// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "Sacramento.h"

// Sacramento's primary constructor
ASacramento::ASacramento()
	
{

	// Set size for the collision capsule 
	GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);

	// Rotate when the AI controller wants to rotate Sacramento
	bUseControllerRotationPitch = true;
	bUseControllerRotationYaw = true;
	bUseControllerRotationRoll = true;

	// Therfore, set up the stats for Sacramento's left hand weapon, then give sacramento this weapon, the skeletal mesh is given to them in editor
	Sac_ActiveWeaponStats = CreateDefaultSubobject<class UWeaponStatistics>(TEXT("Sac_RightHandActiveWeaponStats"));

	// Give this character their intended character name
	C_Name = "Sacramento";

	// Set Sacramento's health values to the lower than the player's initial health values, where applicible
	C_Health = 78.0f;
	C_MaxHealth = 78.0f;
	C_MinHealth = 0.0f;

	CurrentStatus = ESacramentoStatus::SS_GiveIntro;

	// It is not yet time to equip their primary weapon
	bIsTimeToEquipPrimary = false;

	// They of course, also do not have their shotgun ready to fire
	bHasShotgunReady = false;

	// They are not reloading it either
	bReloadingPrimaryWeapon = false;

	// They will have not given their introduction yet as well
	bHasGivenIntroduction = false;

	// The player cannot have answered the any of the introduction questions either
	PlayersFirstIntroQuestionAnswer = "";
	PlayersWontMindStayingQuestionAnswer = "";

	// Sacramento will not be hostile towards the player just yet, if at all
	bIsHostileTowardsDefaultTarget = false;

	/* Sacramento is the first NPC the player will meet, fighting them will not be too hard, 
	so they won't be as effective as the player in combat as they cannot wear armour
	*/
	bCanWearArmour = false;

	// It will not be yet time for Sacramento to go into more detail about their plan, as the player may not even be friendly towards Sacramento
	bTimeToDetailControlPartsPlan = false;

	/* It will not be time just yet, to show the player their Rocket Launcher,
	nor will they have shown the player their Rocket Launcher, or stowed it back into their backpack
	*/

	bTimeToShowLauncherToPlayer = false;
	bHasShownPlayerLauncher = false;
	bHasStowedRocketLauncher = false;
}

/** Sacramento has now provided their introduction to the player, completly */
void ASacramento::HasNowGivenIntroduction()
{
	bHasGivenIntroduction = true;
}

/** Modify IsTimeToEquipPrimary to true if it is time to do so */
void ASacramento::TimeToEquipPrimary()
{
	bIsTimeToEquipPrimary = true;
}

/** Modify ReloadingPrimaryWeapon as and when required */
void ASacramento::NowReloadingPrimaryWeapon()
{
	bReloadingPrimaryWeapon = true;
}

void ASacramento::NotReloadingPrimaryWeapon()
{
	bReloadingPrimaryWeapon = false;
}

/** This function will be called when Sacramento is ready to fire their shotgun (has the weapon drawn) */
void ASacramento::ReadyToFireShotgun()
{
	bHasShotgunReady = true;
}

/** Initialise Sacramento's first target location */
void ASacramento::InitiliseTargetLocation(FVector InitTargetLocal)
{
	StartingLocation = InitTargetLocal;
}

// Modify the stats. for Sacramento's left hand active weapon, not the skeletal mesh
void ASacramento::ModLeftHandActWepStats(UWeaponStatistics* NewActiveWeaponStats)
{
	Sac_ActiveWeaponStats = NewActiveWeaponStats;
}


/** Modify Sacramento's health, either positivly or negativly */
void ASacramento::ModifyHealth(float HealthChangeValue)
{
	// Call Super first
	Super::ModifyHealth(HealthChangeValue);

	// Sacramento has been defeated, do what is required to show them as such
	if (C_Health == C_MinHealth)
	{
		IsAtMinHealth();
	}
}

/** Check if Sacramento is at their minimum health value */
bool ASacramento::IsSacramentoAtMinHeal()
{
	if (C_Health == C_MinHealth)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void ASacramento::IsAtMinHealth_Implementation()
{

}

/** Get the player's first introduction question answer, then set PlayersFirstIntroQuestionAnswer to the appropirate value */
FString ASacramento::GetPlayersFirstIntroQuestionAnswer(FString PlayersAnswer)
{
	if (PlayersAnswer == "No where in particular")
	{
		PlayersFirstIntroQuestionAnswer = "No where in particular";
	}
	else if (PlayersAnswer == "I am waiting for this robot to tell me")
	{
		PlayersFirstIntroQuestionAnswer = "I am waiting for this robot to tell me";
	}
	else if (PlayersAnswer == "I do not know...")
	{
		PlayersFirstIntroQuestionAnswer = "I do not know...";
	}
	// If the player gives anything else though, the answer will be that of an 'Answer of no effect'
	else
	{
		PlayersFirstIntroQuestionAnswer = "Answer of no effect";
	}

	// The answer will be returned by this function for ease of use
	return PlayersFirstIntroQuestionAnswer;
}

/** Get the player's answer to 'you won't mind staying now will you?' question answer, then set PlayersWontMindStayingQuestionAnswer to the appropirate value */
FString ASacramento::GetPlayersWontMindStayingIntroQuestionAnswer(FString PlayersAnswer)
{
	if (PlayersAnswer == "Yes")
	{
		PlayersWontMindStayingQuestionAnswer = "Yes";
	}
	else if (PlayersAnswer == "No")
	{
		PlayersWontMindStayingQuestionAnswer = "No";
	}
	else if (PlayersAnswer == "Maybe")
	{
		PlayersWontMindStayingQuestionAnswer = "Maybe";
	}
	else
	{
		PlayersWontMindStayingQuestionAnswer = "Answer of no effect";
	}
	
	return PlayersWontMindStayingQuestionAnswer;
}

/** For one of, or many of, the different reasons for such behavior, Sacramento is now hostile towards their default target */
void ASacramento::SacramentoNowHostileTowardsTarget()
{
	bIsHostileTowardsDefaultTarget = true;
} 

/** Modify the required flags for showing the player a certain weapon that is part of their plan */
void ASacramento::IsNowTimeToShowLauncherToPlayer()
{
	bTimeToShowLauncherToPlayer = true;
}

// This is the only function of these four, that modify a flag to false
void ASacramento::NoLongerTimeToShowLauncher()
{
	bTimeToShowLauncherToPlayer = false;
}

void ASacramento::HasNowShownPlayerLauncher()
{
	bHasShownPlayerLauncher = true;
}

void ASacramento::HasNowStowedRocketLauncher()
{
	bHasStowedRocketLauncher = true;
}

void ASacramento::TimeToDetailControlablePartsPlanToPlayer()
{
	bTimeToDetailControlPartsPlan = true;
}