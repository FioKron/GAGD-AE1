// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "QTBDArmour.h"

// A blank constructor for now
AQTBDArmour::AQTBDArmour()	
{

}




