// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "QTBDWeapon.h"


/** The default constructor for a weapon, performs one validation check for now */
AQTBDWeapon::AQTBDWeapon()
{
	// If this weapon does not use ammo. Set all of the vars. of this weapon, regarding ammo to zero, the weapon also does not require reloading hence
	if (bUsesAmmo == false)
	{
		InitialAmmoCount = 0.0f;
		MaximumAmmoCount = 0.0f;
		AmmoPerStorageMech = 0.0f;
		CurrentAmmoInStorMech = 0.0f;
		WeaponReloadDuration = 0.0f;
	}
}
