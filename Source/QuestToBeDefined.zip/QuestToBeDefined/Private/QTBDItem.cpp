// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "QTBDItem.h"


AQTBDItem::AQTBDItem()
{
	// The player will not be overlaping this item, upon the iteme spawning into the level
	bIsPlayerOverlapingPickupSphere = false;

	// The player can't have picked up this item yet either
	bHasBeenPickedUp = false;
}


/** Set this flag to true */
void AQTBDItem::PlayerOverlapingPickupSphere()
{
	bIsPlayerOverlapingPickupSphere = true;
}

/** Set this flag to false */
void AQTBDItem::PlayerNotOverlapingPickupSphere()
{
	bIsPlayerOverlapingPickupSphere = false;
}

// Implementation is provided in Blueprint for these functions:
void AQTBDItem::OnItemPickup_Implementation()
{

}

void AQTBDItem::TimeForExplosion_Implementation()
{

}

// Before returning; update the appropriate member variable:
FQuat AQTBDItem::GetQTBDEntQuaternion()
{
	AltnerateTransformSystem = GetActorQuat();

	return AltnerateTransformSystem;
}

/** Called whenever the item has been picked up, also fires off an event that blueprint can use */
void AQTBDItem::NowInPlayerInventory()
{
	bHasBeenPickedUp = true;

	// Call this event for blueprint to handle
	OnItemPickup();
}


