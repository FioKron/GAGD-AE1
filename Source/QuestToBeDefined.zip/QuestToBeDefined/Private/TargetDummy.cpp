// Fill out your copyright notice in the Description page of Project Settings.

#include "QuestToBeDefined.h"
#include "TargetDummy.h"


ATargetDummy::ATargetDummy()
{
	// Set the Target Dummy's current health to 10000 for now
	CurrentHealth = 10000.0f;
}

/*
Add the input value to the Target Dummy's current health
@HealthValue: The value to add to the Dummy's health
*/
void ATargetDummy::ModifyHealth(float HealthValue)
{
	CurrentHealth += HealthValue;

	// The Dummy's health cannot be below 0 though
	if (CurrentHealth < 0.0f)
	{
		CurrentHealth = 0.0f;
		
		// As the target dummy is now at zero health, fire this event
		IsAtZeroHealth();
	}
}

float ATargetDummy::GetCurrentHealth()
{
	if (CurrentHealth != NULL)
	{
		return CurrentHealth;
	}
	else
	{
		return NULL;
	}
}

void ATargetDummy::IsAtZeroHealth_Implementation()
{

}